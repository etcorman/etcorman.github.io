function mesh = MeshLB(mesh,N)
% This method searches for meshname.mat if it exists and loads that. 
% Otherwise it tries to load meshname.off or meshname.obj, computes LB
% matrix/eigenstuff, and caches it for next time in meshname.mat.  It
% also can load the LB matrix and fill in eigenstuff if necessary.
% loadMeshLB returns two structures used for mesh and LB information.
%
% "Mesh" will be a structure storing all mesh data.

    mesh = compute_LB(mesh);
    
    mesh = compute_functional_basis_weigthed_LB(mesh,N);%max(N+1,k+1));

end

%%% 
% Compute weighted and unweighted cot LB
% Note that area weights are normalized to sum to 1
%%
function mesh = compute_LB(mesh)
    % triangle areas
    X = mesh.vertices; T = mesh.triangles;
    N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
    mesh.ta = sqrt(sum(N.^2,2))/2;    
    
    [W, A] = cotLaplacian(mesh);
    mesh.origAreaWeights = 2*A;
    mesh.areaWeights = 2*A;
    % % Normalize mesh area to sum to 1
    mesh.areaWeights = mesh.areaWeights / sum(mesh.areaWeights);   
    % Using **negative** cotLaplacian
    mesh.cotLaplace = -2*W;
    
    %% For convenience...
    mesh.A = spdiags(mesh.areaWeights,0,mesh.nv,mesh.nv);
    mesh.Ai = spdiags(1./mesh.areaWeights,0,mesh.nv,mesh.nv);
    mesh.L = mesh.cotLaplace;
    mesh.Lw = mesh.Ai*mesh.L;
end

%%% 
% Eigenstuff of weighted LB
%%
function mesh = compute_functional_basis_weigthed_LB(mesh,N)
    [evecs, evals] = eigs(mesh.L, mesh.A, min(N,mesh.nv), -1e-3);
    evals = diag(evals);
    
    evecs = repmat(sign(evecs(1,:)), size(evecs, 1), 1).*evecs;
    mesh.laplaceBasis = evecs;
    mesh.eigenvalues = evals;
    
    mesh.LB.basis = evecs;
%     mesh.LB.basisi = evecs'*mesh.A;
    mesh.LB.basisi = pinv(mesh.LB.basis);
    mesh.LB.evals = evals;    
end
