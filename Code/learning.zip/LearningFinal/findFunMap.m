function X = findFunMap(F, G, D, W, alpha, R)
% Solve min_C  0.5 ||(C F - G) D||^2 + 0.5*alpha ||W.*C||^2

X = zeros(size(W));
X(1,1) = 1;

if ~exist('R', 'var')
    B = F(2:end,:)*(D*D')*F(2:end,:)';
    b = G*(D*D')*F(2:end,:)';
    b(1,:) = b(1,:) - X(1,1)*F(1,:)*(D*D')*F(2:end,:)';
    for i = 1:size(W,2)
        R = chol(B + alpha*diag(W(i,2:end).^2));
        X(i,2:end) = (R\(R'\b(i,:)'))';
    end
else
    b = G*(D*D')*F(2:end,:)';
    b(1,:) = b(1,:) - X(1,1)*F(1,:)*(D*D')*F(2:end,:)';
    for i = 1:size(W,2)
        X(i,2:end) = (R{i}\(R{i}'\b(i,:)'))';
    end
end
