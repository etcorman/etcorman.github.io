function X = findAdj(F, b, D, W, alpha, R)
% Solve min_C  0.5 ||C F D - b ||^2 + 0.5*alpha ||W.*C||^2

X = zeros(size(W));

if ~exist('R', 'var')
    B = F(2:end,:)*(D*D')*F(2:end,:)';
    b = b(:,2:end);
    for i = 1:size(W,2)
        R = chol(B + alpha*diag(W(i,2:end).^2));
        X(i,2:end) = (R\(R'\b(i,:)'))';
    end
else
    b = b(:,2:end);
    for i = 1:size(W,2)
        X(i,2:end) = (R{i}\(R{i}'\b(i,:)'))';
    end
end