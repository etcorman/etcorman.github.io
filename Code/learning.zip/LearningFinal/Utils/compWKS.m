function wks = compWKS(fctp, vp, N, wks_variance)

npt = size(fctp, 2);

% Parameters

% N = 300; % number of evaluations of WKS
% wks_variance = 6;%6; % variance of the WKS gaussian (wih respect to the 
% difference of the two first eigenvalues). For easy or precision tasks 
% (eg. matching with only isometric deformations) you can take it smaller

wks = zeros(N, npt);

log_vp = log(max(abs(vp), 1e-6))';
e = linspace(log_vp(3), (max(log_vp))/1.02, N);  
sigma = (e(2) - e(1))*wks_variance;

C = zeros(1,N); %weights used for the normalization of f_E

for i = 1:N
    wks(i, :) = sum(fctp.^2.*repmat( exp((-(e(i) - log_vp).^2) ./ (2*sigma.^2)), npt, 1)');
    C(i) = sum(exp((-(e(i)-log_vp).^2)/(2*sigma.^2)));
end

% normalize WKS
wks = wks./repmat(C, npt, 1)';