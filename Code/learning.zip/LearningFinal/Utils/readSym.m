function p = readSym(filename)

fileID = fopen(filename, 'r');

s = textscan(fileID, '%d');
p = double(s{1});

if (min(p) == 0)
    p = p + 1;
end

fclose(fileID);