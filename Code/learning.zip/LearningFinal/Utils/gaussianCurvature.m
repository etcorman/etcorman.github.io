function y = gaussianCurvature(mesh)

y = zeros(mesh.nv, 1);

Tri = mesh.triangles;
Vert = mesh.vertices;

area = full(mesh.areaWeights);

for i = 1:mesh.nv
    
    [numts, ~] = find(Tri == i);
    x1 = Vert(i,:)';
    
    for j = 1:length(numts)
        if (i == Tri(numts(j), 1))
            vx2 = Tri(numts(j), 2);
            vx3 = Tri(numts(j), 3);
            
            x2 = Vert(vx2,:)';
            x3 = Vert(vx3,:)';
        elseif (i == Tri(numts(j), 2))
            vx2 = Tri(numts(j), 3);
            vx3 = Tri(numts(j), 1);
            
            x2 = Vert(vx2,:)';
            x3 = Vert(vx3,:)';
        else
            vx2 = Tri(numts(j), 1);
            vx3 = Tri(numts(j), 2);
            
            x2 = Vert(vx2,:)';
            x3 = Vert(vx3,:)';
        end
        
        a = (x2 - x1)/norm(x2 - x1);
        b = (x3 - x1)/norm(x3 - x1);
        
        sintheta = norm(cross(a, b));
        costheta = dot(a, b);
        y(i) = y(i) + atan2(sintheta, costheta);
    end
    
    y(i) = 3*(2*pi - y(i))/area(i);
end