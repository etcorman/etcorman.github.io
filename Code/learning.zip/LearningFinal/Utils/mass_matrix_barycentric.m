function M = mass_matrix_barycentric(mesh)

T = mesh.triangles; 
Ar = mesh.ta;
nv = mesh.nv;

I = [T(:,1);T(:,2);T(:,3)];
J = [T(:,2);T(:,3);T(:,1)];
Mij = 1/12*[Ar; Ar; Ar];
Mji = Mij;
Mii = 1/6*[Ar; Ar; Ar];
In = [I;J;I];
Jn = [J;I;I];
Mn = [Mij;Mji;Mii];
M = sparse(In,Jn,Mn,nv,nv);
