function [Pts, Vx, Face] = SHREC_landmark(filename)

Pts = zeros(6, 3);
Vx = zeros(6, 1);
Face = zeros(6, 1);

fid = fopen(filename,'r');
if( fid==-1 )
    error('Cannot open the file.');
    return;
end

for i = 1:6
    str = fgets(fid);   % -1 if eof
    if ~strcmp(str(1:10), '<landmark>')
        error('The file is not a landmark file.');
    end
    
    str = fgets(fid);
    if ~strcmp(str(1:6), '<name>')
        error('The file is not a landmark file.');
    end
    
    str = fgets(fid);
%     disp(str);
    
    str = fgets(fid);
    if ~strcmp(str(1:7), '</name>')
        error('The file is not a landmark file.');
    end
    
    str = fgets(fid);
    if ~strcmp(str(1:13), '<coordinates>')
        error('The file is not a landmark file.');
    end
    
    Pts(i,:) = fscanf(fid,'%lf %lf %lf\n');
    
    str = fgets(fid);
    if ~strcmp(str(1:14), '</coordinates>')
        error('The file is not a landmark file.');
    end
    
    str = fgets(fid);
    if ~strcmp(str(1:10), '<triangle>')
        error('The file is not a landmark file.');
    end
    
    Face(i) = fscanf(fid,'%d\n');
    
    str = fgets(fid);
    if ~strcmp(str(1:11), '</triangle>')
        error('The file is not a landmark file.');
    end
    
    str = fgets(fid);
    if ~strcmp(str(1:6), '<node>')
        error('The file is not a landmark file.');
    end
    
    Vx(i) = fscanf(fid,'%d\n');
    
    str = fgets(fid);
    if ~strcmp(str(1:7), '</node>')
        error('The file is not a landmark file.');
    end
    
    str = fgets(fid);
    if ~strcmp(str(1:11), '</landmark>')
        error('The file is not a landmark file.');
    end
end

fclose(fid);