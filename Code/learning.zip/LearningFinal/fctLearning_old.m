function [F, mask] = fctLearning_old(mesh)

Delta = mesh.cotLaplace;

mask = 0;

% HKS
L1.A = mesh.A;
L1.evecs = mesh.LB.basis;
L1.evals = mesh.LB.evals;
tempDesc = logspace(-3, -1, 50);
f1 = hks(L1, tempDesc);
F = f1;
mask = ones(size(f1, 2), 1)*(max(mask) + 1);

% % Distance to point
% numx = [1, 500, 1650, 3000, 15000, 20000]; % Known correspondences
% % numx = [1650, 20000];
% tempDesc = logspace(-2, -1, 50);
% f2 = hkm(L1, numx, tempDesc);
% F = [F, f2];
% mask = [mask; ones(size(f2, 1))*(max(mask) + 1)];

% WKS
% f2 = wks(L1, tempDesc);
% f2 = compWKS(mesh.LB.basis', mesh.LB.evals, 50, 10)';
f3 = compWKS(mesh.LB.basis', mesh.LB.evals, 50, 6)';
f4 = compWKS(mesh.LB.basis', mesh.LB.evals, 50, 1)';
f2 = compWKS(mesh.LB.basis', mesh.LB.evals, 50, 0.5)';
F = [F, f2, f3, f4];
mask = [mask; ones(size(f2, 2), 1)*(max(mask) + 1)];
mask = [mask; ones(size(f3, 2), 1)*(max(mask) + 1)];
mask = [mask; ones(size(f4, 2), 1)*(max(mask) + 1)];

% Mean curvature
Max = 25; step = 5;
meanCurv = sqrt(sum((Delta*mesh.vertices).^2, 2));
f5 = zeros(mesh.nv, Max);
f6 = zeros(mesh.nv, Max);
f5(:,1) = meanCurv;%.*(meanCurv < median(meanCurv));
f6(:,1) = log(abs(meanCurv) + 1e-10);%.*(meanCurv > median(meanCurv));
for i = 2:Max
    f5(:, i) = (speye(size(Delta)) - step*Delta)\f5(:, i-1);
    f6(:, i) = (speye(size(Delta)) - step*Delta)\f6(:, i-1);
end

F = [F, f5, f6];
mask = [mask; ones(size(f5, 2), 1)*(max(mask) + 1)];
mask = [mask; ones(size(f6, 2), 1)*(max(mask) + 1)];

% Mesh Saliency
f = meshSaliency(mesh.vertices, meanCurv, [0.1, linspace(1, 100, 9)]);
F = [F, f];
mask = [mask; ones(size(f, 2), 1)*(max(mask) + 1)];

% Gaussian curvature
Max = 25; step = 5;
gaussCurv = gaussianCurvature(mesh);
gaussPos = zeros(mesh.nv, Max);
gaussNeg = zeros(mesh.nv, Max);
gaussPos(:,1) = gaussCurv;%.*(gaussCurv < 0);
gaussNeg(:,1) = log(abs(gaussCurv) + 1e-10);%.*(gaussCurv >= 0);
for i = 2:Max
    gaussPos(:, i) = (speye(size(Delta)) - step*Delta)\gaussPos(:, i-1);
    gaussNeg(:, i) = (speye(size(Delta)) - step*Delta)\gaussNeg(:, i-1);
end
F = [F, gaussPos, gaussNeg];
mask = [mask; ones(size(gaussPos, 2), 1)*(max(mask) + 1)];
mask = [mask; ones(size(gaussNeg, 2), 1)*(max(mask) + 1)];
