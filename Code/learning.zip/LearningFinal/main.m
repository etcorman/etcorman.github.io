clear all; close all; clc;
% matlabpool;

addpath(genpath(pwd));

nbEigen = 50;
range = 1:3;
Max = length(range);

pathMesh = '../../TOSCA/Shapes/';
meshName = 'cat';
meshRef = read_off([pathMesh, meshName, '0.off']);

meshRef = MeshLB(meshRef, nbEigen);

% [fref, mask] = fctLearning_old(meshRef);
[fref, mask] = fctLearning(meshRef);
FRef = projectFunction(fref, meshRef.LB.basis, meshRef.A);
normalization = sqrt(sum(fref.^2));
FRef = FRef./repmat(normalization, [nbEigen, 1]);

nbFct = size(FRef, 2);

%% Computes descriptors
map = zeros(nbEigen, nbEigen, Max); % Ref to i
F = zeros(nbEigen, nbFct, Max);
eigVal = zeros(nbEigen, Max);
for i = 1:Max
    
    disp(['Shape: ', meshName, num2str(range(i))]);
    mesh = read_off([pathMesh, meshName, num2str(range(i)), '.off']);
    
    mesh = MeshLB(mesh, nbEigen);
    
    map(:, :, i) = mesh.LB.basis'*mesh.A*meshRef.LB.basis;

%     [f, ~] = fctLearning_old(mesh);
    [f, ~] = fctLearning(mesh);
    eigVal(:,i) = mesh.eigenvalues;
    
    % Projection and normalization
    normalization = sqrt(sum(f.^2));
    F(:,:,i) = projectFunction(f, mesh.LB.basis, mesh.A, normalization);
end

%% Initialization
FmapWeight = cell(Max, 3);
SubSpace = cell(3,1);

W = zeros(nbEigen, nbEigen, Max);
for i = 1:Max
    W(:,:,i) = abs(repmat(abs(eigVal(:,i)) , [1, nbEigen]) - repmat(abs(meshRef.eigenvalues)' , [nbEigen, 1])) + 1;
end

alpha = 1e-3;
xinit = ones(nbFct, 1);

%% Set parameter from initial map
Soli = zeros(nbEigen, nbEigen, Max);
SvInit = zeros(nbEigen, Max);
for i = 1:Max
    Soli(:,:,i) = findFunMap(FRef, F(:,:,i), diag(xinit), W(:,:,i), alpha);
    SvInit(:,i) = svd(Soli(:,:,i) - map(:,:,i));
end

epsilon = flipud(mean(SvInit, 2));
epsilon = epsilon(sum(cumsum(epsilon)/sum(epsilon) <= 0.1));

%% Learning: weight per category
funObj = @(x) oracle(x, map, FRef, F, W, alpha, mask, 'l0', epsilon);
option.MaxIter = 600;
option.MaxFunEvals = option.MaxIter;
[xCat, fmin, exitflag] = minFunc(funObj, xinit, option);
Dcat = diag(xCat);

% Stable functions
A = zeros(nbEigen*Max, nbEigen);
for i = 1:Max
    FmapWeight{i,2} = findFunMap(FRef, F(:,:,i), Dcat, W(:,:,i), alpha);
    A(nbEigen*(i-1) + 1:nbEigen*i,1:end) = FmapWeight{i,2} - map(:,:,i);
end

[~, ~, V] = svd(A);
SubSpace{2} = fliplr(V);

%% Learning: one weight
mask = ones(1, nbFct);

funObj = @(x) oracle(x, map, FRef, F, W, alpha, mask, 'l0', epsilon);
option.MaxIter = 600;
option.MaxFunEvals = option.MaxIter;
[xOne, fmin, exitflag] = minFunc(funObj, xinit, option);
Done = diag(xOne);

% Stable functions
A = zeros(nbEigen*Max, nbEigen);
for i = 1:Max
    FmapWeight{i,1} = findFunMap(FRef, F(:,:,i), Done, W(:,:,i), alpha);
    A(nbEigen*(i-1) + 1:nbEigen*i,1:end) = FmapWeight{i,1} - map(:,:,i);
end

[~, ~, V] = svd(A);
SubSpace{1} = fliplr(V);

%% Learning: weight per function
mask = 1:nbFct;

funObj = @(x) oracle(x, map, FRef, F, W, alpha, mask, 'l0', epsilon);
option.MaxIter = 600;
option.MaxFunEvals = option.MaxIter;
[xAll, fmin, exitflag] = minFunc(funObj, xinit, option);
Dall = diag(xAll);

% Stable functions
A = zeros(nbEigen*Max, nbEigen);
for i = 1:Max
    FmapWeight{i,3} = findFunMap(FRef, F(:,:,i), Dall, W(:,:,i), alpha);
    A(nbEigen*(i-1) + 1:nbEigen*i,1:end) = FmapWeight{i,3} - map(:,:,i);
end

[~, ~, V] = svd(A);
SubSpace{3} = fliplr(V);

%% Show weights
figure;
plot(1:nbFct, abs(xOne), 1:nbFct, abs(xCat), 1:nbFct, abs(xAll));
title('Weights');
legend('One Weight', 'Category Weight', 'All Weight');

%% Test shape n+1
% Load new shape
disp(['Shape: ', meshName, num2str(range(end)+1)]);
mesh = read_off([pathMesh, meshName, num2str(range(end)+1), '.off']);

mesh = MeshLB(mesh, nbEigen);
WTest = abs(repmat(abs(mesh.eigenvalues) , [1, nbEigen]) - repmat(abs(meshRef.eigenvalues)' , [nbEigen, 1]))+1;

% Compute descriptors
% [f, ~] = fctLearning_old(mesh);
[f, ~] = fctLearning(mesh);
normalization = sqrt(sum(f.^2));
FTest = projectFunction(f, mesh.LB.basis, mesh.A, normalization);

% Conpute weighted functional map
FmapTest{1} = findFunMap(FRef, FTest, Done, WTest, alpha);
FmapTest{2} = findFunMap(FRef, FTest, Dcat, WTest, alpha);
FmapTest{3} = findFunMap(FRef, FTest, Dall, WTest, alpha);

% Naive map
FmapTestInit = findFunMap(FRef, FTest, diag(xinit), WTest, alpha);

% Ground truth
mapTest = mesh.LB.basis'*mesh.A*meshRef.LB.basis;

% Plot first five stable functions
for i = 1:min(5, nbEigen)
    figure;
    subplot(3, 2, 1); trisurf(meshRef.triangles, meshRef.vertices(:,1), meshRef.vertices(:,2), meshRef.vertices(:,3), meshRef.LB.basis*SubSpace{1}(:,i));
    title('Function'); axis equal; shading interp; colorbar;
    subplot(3, 2, 2); trisurf(mesh.triangles, mesh.vertices(:,1), mesh.vertices(:,2), mesh.vertices(:,3), mesh.LB.basis*FmapTest{1}*SubSpace{1}(:,i));
    title('One Weight'); axis equal; shading interp; colorbar;
    
    subplot(3, 2, 3); trisurf(meshRef.triangles, meshRef.vertices(:,1), meshRef.vertices(:,2), meshRef.vertices(:,3), meshRef.LB.basis*SubSpace{2}(:,i));
    title('Function'); axis equal; shading interp; colorbar;
    subplot(3, 2, 4); trisurf(mesh.triangles, mesh.vertices(:,1), mesh.vertices(:,2), mesh.vertices(:,3), mesh.LB.basis*FmapTest{2}*SubSpace{2}(:,i));
    title('Category Weight'); axis equal; shading interp; colorbar;
    
    subplot(3, 2, 5); trisurf(meshRef.triangles, meshRef.vertices(:,1), meshRef.vertices(:,2), meshRef.vertices(:,3), meshRef.LB.basis*SubSpace{3}(:,i));
    title('Function'); axis equal; shading interp; colorbar;
    subplot(3, 2, 6); trisurf(mesh.triangles, mesh.vertices(:,1), mesh.vertices(:,2), mesh.vertices(:,3), mesh.LB.basis*FmapTest{3}*SubSpace{3}(:,i));
    title('All Weight'); axis equal; shading interp; colorbar;
end

%% Error correspondences
sym = readSym(['./tosca_symmetry_maps/', meshName, '0.map']);
nbPt = 1000;
idx = randperm(mesh.nv);
idx = sort(idx(1:nbPt))';

fp0 = meshRef.LB.basis;
fp1 = mesh.LB.basis;

figure;
hold all;
pi = knnsearch((mapTest*fp0')', fp1(idx, :));
ErrorCorrespondences(mesh, pi, idx, sym);

pi = knnsearch((FmapTestInit*fp0')', fp1(idx, :));
ErrorCorrespondences(mesh, pi, idx, sym);

for i = 1:3
    pi = knnsearch((FmapTest{i}*fp0')', fp1(idx, :));
    ErrorCorrespondences(mesh, pi, idx, sym);

    spaceReduction = floor(nbEigen/2);
    pi = knnsearch((FmapTest{i}*SubSpace{i}(:,1:spaceReduction)*SubSpace{i}(:,1:spaceReduction)'*fp0')', fp1(idx, :));
    ErrorCorrespondences(mesh, pi, idx, sym);
end
hold off;

legend('Ground truth', 'Naive map', 'One Weight', 'Reduced One Weight', 'Category Weight', 'Reduced Category Weight', 'All Weight', 'Reduced All Weight');

% matlabpool close;