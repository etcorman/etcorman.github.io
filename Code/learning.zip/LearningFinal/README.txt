Supervised Descriptor Learning for Non-Rigid Shape Matching,
Etienne Corman, Maks Ovsjanikov, Antonin Chambolle
Sixth Workshop on Non-Rigid Shape Analysis and Deformable Image Alignment (NORDIA), Proc. ECCV Workshops, 2014

- In "main.m" change the variable "pathMesh" to the path of the TOSCA dataset (http://tosca.cs.technion.ac.il/book/resources_data.html).
- Launch "main.m" to obtain figure 5b of the paper.

