function [f, df] = oracle(x, map, F, G, W, alpha, mask, type, epsilon)

if (nargin == 6)
    type = 'nuclear';
    mask = 1:size(x);
    epsilon = 1e-3;
end
if (nargin == 7)
    type = 'nuclear';
    epsilon = 1e-3;
end
if (nargin == 8)
    epsilon = 1e-3;
end

Max = size(map, 3);
D = diag(x);

g = zeros(Max, 1);
dD = zeros(length(x), Max);
parfor j = 1:Max
    [dd, h] = gradientSing(map(:,:,j), F, G(:,:,j), D, W(:,:,j), alpha, mask, type, epsilon);
    
    g(j) = h;
    dD(:,j) = dd;
end
df = sum(dD, 2);
f = sum(g);
end

function [dD, f] = gradientSing(map, F, G, D, W, alpha, mask, type, epsilon)
% Find the gradient of argmin_C  f(C, D) = 0.5 ||(C F - G) D||^2 + 0.5*alpha ||C.*W||^2
% dC = \nabla_D f(CSol, D)
% mask : sub derivative to compute, it is a vector of length size(D,1). The
% deriction of the subderivative is given by non zero integer. ex [1 0 2 2]
% will yield [\partial_1, \partial_3 + \partial_4]

% Pre-compute Cholesky factorization
CholFact = cell(size(W, 1), 1);
for j = 1:size(W, 1)
    CholFact{j} = chol(F(2:end,:)*(D*D')*F(2:end,:)' + alpha*diag(W(j,2:end).^2));
end

% Solution
CSol = findFunMap(F, G, D, W, alpha, CholFact);
[U, S, V] = svd(CSol - map);
s = diag(S);

% Type of norm
if strcmp(type, 'fro')
    % Frobenius-norm 
    reg = s;
    f = sum(sum((CSol - map).^2));
end
if strcmp(type, 'nuclear')
    % l1-norm regularization
    reg = s./sqrt(s.^2 + epsilon^2);
    f = sum(sqrt(s.^2 + epsilon^2));
end
if strcmp(type, 'l0')
    % l0-norm regularization
    ep = epsilon^2/9; % f(epsilon) = 0.9
    reg = 2*ep*s./(s.^2 + ep).^2;
    f = sum(s.^2./(s.^2 + ep));
end

% Adjoint state
X = findAdj(F, U*diag(reg)*V', D, W, alpha, CholFact);

% Directional derivative
dD = zeros(size(D, 1), 1);
for i = 1:max(mask)
    idx = (mask == i);
    DDt = diag(idx);
    DDt = DDt*D' + D*DDt';
    
    dD(idx) = sum(sum(((G - CSol*F)*DDt*F').*X)); % Gradient of the regularization
end

end