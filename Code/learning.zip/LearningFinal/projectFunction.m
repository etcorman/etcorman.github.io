function F = projectFunction(fct, basis, A, normalization)

F = basis'*A*fct;

if exist('normalization', 'var')
    F = F./repmat(normalization, [size(F, 1), 1]);
end