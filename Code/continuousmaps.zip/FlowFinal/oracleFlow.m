function [f, df] = oracleFlow(C, CRef, a, basisVfOp, Y, type)

nbVFPart = size(basisVfOp, 3);
nbFctBasis = size(basisVfOp, 1);

Dv = zeros(nbFctBasis);
for j = 1:nbVFPart
    Dv = Dv + a(j)*basisVfOp(:, :, j);
end

[X, Jac] = jacExpm(Dv, basisVfOp);

if (strcmp(type, 'fro'))
    f = sum(sum(((X*C - CRef)*Y).^2));
end
    
if (strcmp(type, 'nuclear'))
    ep = 1e-3;
    [U, S, V] = svd((X*C - CRef)*Y);
    s = diag(S);
    reg = s./sqrt(s.^2 + ep^2);
    S(1:size(S,1)+1:end) = reg;
    f = sum(sqrt(s.^2 + ep^2));
end

df = zeros(nbVFPart, 1);
for j = 1:nbVFPart
    if (strcmp(type, 'fro'))
        df(j) = sum(sum((Jac(:,:,j)*C*Y).*((X*C - CRef)*Y)));
    end
    
    if (strcmp(type, 'nuclear'))
        df(j) = sum(sum((Jac(:,:,j)*C*Y).*(U*S*V')));
    end
end