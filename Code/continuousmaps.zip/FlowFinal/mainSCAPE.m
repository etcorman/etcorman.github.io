clear all; close all; clc;

addpath(genpath(pwd));

pathSCAPE = '../SCAPE/';

numSrc = 1;
numTar = 2;

% From map learning
fileCache = ['./Learning/Cache/weight_', nameSCAPE(numSrc), '_', nameSCAPE(numTar), '.mat'];
if ~exist(fileCache, 'file')
    learnMapSCAPE(pathSCAPE, numSrc, numTar, 0:10, 150, 70);
end
load(fileCache, 'mesh0', 'mesh1', 'CRef', 'Ysub');

nbFctBasis = size(mesh1.LB.basis, 2);
nbVFBasis = size(mesh0.fvf.hvf, 2);

%% Functional maps
% BIM
pBim = readSym(['../bim_maps/scape/', nameSCAPE(numSrc), '_', nameSCAPE(numTar), '.map']);
FmapBim = mesh1.LB.basis'*mesh1.A*mesh0.LB.basis(pBim,:);

%Ground truth
FmapTruth = mesh1.LB.basis'*mesh1.A*mesh0.LB.basis;

%% Convertion
basisVf0 = reshape(mesh0.fvf.hvf, mesh0.nf, 3, nbVFBasis);
basisVfOp0 = reshape(mesh0.fvf.hbasis, nbFctBasis, nbFctBasis, nbVFBasis);

basisVf1 = reshape(mesh1.fvf.hvf, mesh1.nf, 3, nbVFBasis);
basisVfOp1 = reshape(mesh1.fvf.hbasis, nbFctBasis, nbFctBasis, nbVFBasis);

%% Find the solution of: \min_{D_v} ||(expm(D_v) C - CRef)Y||

% best subspace
Y = Ysub(:,1:70);
% Y = eye(nbFctBasis);

% Start from identity
Cinit = FmapBim;
 
funObj = @(x) oracleFlow(Cinit, CRef, x, basisVfOp1, Y, 'nuclear');
option.MaxIter = 300;
[x, fmin, exitflag] = minFunc(funObj, zeros(nbVFBasis, 1), option);

% Find back vectro field
Dv = zeros(nbFctBasis);
for j = 1:nbVFBasis
    Dv = Dv + x(j)*basisVfOp1(:, :, j);
end
X = expm(Dv);
FmapSol = X*Cinit;

% Show maps
figure;
subplot(2, 2, 1); imagesc(FmapTruth); title(['Ground Truth Fmap']); axis equal;
subplot(2, 2, 2); imagesc(CRef); title('Reference Fmap'); axis equal;
subplot(2, 2, 3); imagesc(FmapBim); title(['BIM Fmap']); axis equal;
subplot(2, 2, 4); imagesc(FmapSol); title(['Solution Fmap']); axis equal;

sum(svd(FmapBim - FmapTruth))/sum(svd(FmapTruth))
sum(svd(CRef - FmapTruth))/sum(svd(FmapTruth))
sum(svd(FmapSol - FmapTruth))/sum(svd(FmapTruth))

%% Vector field flow
vf = zeros(mesh1.nf, 3);
for j = 1:nbVFBasis
    vf = vf + x(j)*basisVf1(:, :, j);
end
[VertFlow, ~] = integrationVertex(mesh1, 1:mesh1.nv, 1, vf);

NewVert = VertFlow(pBim, :);
pSol = knnsearch(NewVert, mesh1.vertices);

% Show VF
figure;
trisurf(mesh1.triangles, mesh1.vertices(:,1), mesh1.vertices(:,2), mesh1.vertices(:,3), mesh1.LB.basis(:,4));
hold on;
vf_fquiver(mesh1, vf, mesh1.nf);
hold off;
title(['Vector field : FctBasis : ', num2str(nbFctBasis), ' VfBasis : ', num2str(nbVFBasis)]); axis equal;

% Show displacement
VertBim = mesh1.vertices(pBim, :);
figure;
subplot(2, 2, 1); trisurf(mesh1.triangles, mesh1.vertices(:,1), mesh1.vertices(:,2), mesh1.vertices(:,3));  title('Real vertices'); axis equal;
subplot(2, 2, 2); trisurf(mesh1.triangles, VertFlow(:,1), VertFlow(:,2), VertFlow(:,3));  title('Displacement vertices'); axis equal;
subplot(2, 2, 3); trisurf(mesh1.triangles, NewVert(:,1), NewVert(:,2), NewVert(:,3));  title('New vertices'); axis equal;
subplot(2, 2, 4); trisurf(mesh1.triangles, VertBim(:,1), VertBim(:,2), VertBim(:,3));  title('BIMvertices'); axis equal;

%% Graph correspondences
nbPt = 3000;
idx = randperm(mesh1.nv);
idx = sort(idx(1:nbPt))';

% Reference
fp0 = mesh0.LB.basis;
fp1 = mesh1.LB.basis;
[pRef] = knnsearch((CRef*(Y*Y')*fp0')', fp1);

figure;
hold all;
ErrorCorrespondences(mesh0, pSol(idx), idx);

ErrorCorrespondences(mesh0, pRef(idx), idx);

ErrorCorrespondences(mesh0, pBim(idx), idx);

title('Error correspondences on the shape');
legend('Solution Map', 'Reference Fmap', 'BIM');
hold off;

%% RGB Map
center = min(mesh1.vertices);
center = repmat(center, [mesh1.nv, 1]);
vertexcolor = (mesh1.vertices - center)./repmat(max(mesh1.vertices - center), [mesh1.nv, 1]);

vertexcolorRef = vertexcolor(pRef,:);
vertexcolorSol = vertexcolor(pSol,:);
vertexcolorBim = vertexcolor(pBim,:);

figure;
subplot(2, 2, 1); patch('faces', mesh1.triangles, 'vertices', mesh1.vertices, 'facecolor', 'interp',  'edgecolor', 'interp', 'facealpha', 1, 'FaceVertexCData', vertexcolor);
axis equal; view(3); title('Initial');
subplot(2, 2, 2); patch('faces', mesh0.triangles, 'vertices', mesh0.vertices, 'facecolor', 'interp',  'edgecolor', 'interp', 'facealpha', 1, 'FaceVertexCData', vertexcolorSol);
axis equal; view(3); title('Solution');
subplot(2, 2, 3); patch('faces', mesh0.triangles, 'vertices', mesh0.vertices, 'facecolor', 'interp',  'edgecolor', 'interp', 'facealpha', 1, 'FaceVertexCData', vertexcolorBim);
axis equal; view(3); title('BIM');
subplot(2, 2, 4); patch('faces', mesh0.triangles, 'vertices', mesh0.vertices, 'facecolor', 'interp',  'edgecolor', 'interp', 'facealpha', 1, 'FaceVertexCData', vertexcolorRef);
axis equal; view(3); title('Reference Fmap');

%% Texture transfer
pathText = './TextureTransfer/';
meshObj = read_obj([pathText, 'mesh001.obj']);

v2vt = unique([meshObj.f.v(:), meshObj.f.vt(:)], 'rows');
vt = meshObj.vt(v2vt(:,2),:);
vtRef = vt(pRef,:);
vtSol = vt(pSol,:);
vtBim = vt(pBim,:);

options.nm_file = 'uvrefmap_checkeredmap.jpg';
options.face_texcorrd = meshObj.f.v;

nameObj = [nameSCAPE(numTar), '_truth.obj'];
options.object_texture = vt;
write_obj(pathText, nameObj, mesh1.vertices, meshObj.f.v, options);

nameObj = [nameSCAPE(numTar), '_ref.obj'];
options.object_texture = vtRef;
write_obj(pathText, nameObj, mesh1.vertices, meshObj.f.v, options);

nameObj = [nameSCAPE(numTar), '_sol.obj'];
options.object_texture = vtSol;
write_obj(pathText, nameObj, mesh1.vertices, meshObj.f.v, options);

nameObj = [nameSCAPE(numTar), '_bim.obj'];
options.object_texture = vtBim;
write_obj(pathText, nameObj, mesh1.vertices, meshObj.f.v, options);