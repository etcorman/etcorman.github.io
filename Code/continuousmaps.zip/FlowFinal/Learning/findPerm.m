function pi = findPerm(meshi, meshj, Cij, alpha, IterMax, varargin)
% Solve: min ||Cij - phi'*pi*psi||_{\star} + alpha (grad pi f)'*Aj*(grad pi f)
% pi permutation iff sum(pi, 1) = 1 ; sum(pi, 2) = 1 ; pi(i,j) >= 0 ;
% max(pi(i,:)) = 1 or ||pi(i,:)||_2 = 1

phi = meshj.A*meshj.LB.basis;
psi = meshi.LB.basis;
f = meshi.vertices;
f = f./repmat(sqrt(diag(f'*meshi.A*f)'), [size(f, 1), 1]);
Deltaj = sparse(1:meshj.nv, 1:meshj.nv, meshj.areaWeights)*meshj.cotLaplace;
% Deltaj = meshj.cotLaplace;

Kif = zeros(size(f));
for i = 1:size(Kif, 2)
    Kif(:,i) = shermor(f(:,i), f(:,1:i-1), 'l');
end

mu = 1;
lambda = 1e5;

if (isempty(varargin))
%     pi = eye(size(f,1));

%     pi = sparse(1:size(psi, 1), randperm(size(psi, 1)), 1);

%     pi = ones(size(f,1));
    
    [nnidx] = annquery(meshj.LB.basis', Cij*meshi.LB.basis', 1);
    pi = sparse(1:meshi.nv, double(nnidx), 1, meshi.nv, meshj.nv);
else
    pi = varargin{1};
end
X = Cij - phi'*pi*psi;
Y = pi;
Z = pi*f;

fct = zeros(IterMax, 1);
for it = 1:IterMax
    
    Xt = X;
    Yt = Y;
    Zt = Z;

    [X, Y, Z, pi] = rproxF(X, Y, Z, f, Kif, Cij, phi, psi);

    [X, Y, Z] = rproxG(X, Y, Z, Deltaj, alpha, lambda);

    X = X*mu/2 + Xt*(1 - mu/2);
    Y = Y*mu/2 + Yt*(1 - mu/2);
    Z = Z*mu/2 + Zt*(1 - mu/2);
    
    G = sum(face_grads(meshj, pi*f).^2 , 2);
    fct(it) = sum(svd(Cij - phi'*pi*psi)) + alpha*G'*diag(meshj.ta)*G/sum(meshj.ta);
%     if (mod(it,10) == 0)
        disp(['Iteration : ', num2str(it), ' Objective : ', num2str(fct(it)), ' Objective : ', num2str(abs(max(max(pi)) - 1))]);
%     end
end

figure;
plot(fct);
end

function [x, y, z] = rproxG(X, Y, Z, Delta, alpha, lambda)
% Prox of: ||X||_{\star} + alpha ||\grad_j Z||_{L^2} +
% ind(Y(i,j) >= 0 ; max(Y(i,:)) = 1)

% disp('Prox G');
% tic;
    [U, S, V] = svd(X);
    S = max(diag(S) - lambda, 0);
    x = U*diag(S)*V';
    
    % Convex normalization
%     y = max(0, Y);
%     y = min(1, y);

    % Max normalization
%     y = min(1, Y);
%     [~, id] = max(y, [], 2);
%     y(sub2ind(size(y), 1:size(y, 1), id')) = 1;
%     y = max(0, y);
    % l2 normalization
    y = normalizeL2(Y);
%     y = bsxfun(@rdivide, y, sqrt(sum(y.^2, 2)));

    z = (speye(size(Delta)) - 2*lambda*alpha*Delta)\Z;

    %
    x = 2*x - X;
    y = 2*y - Y;
    z = 2*z - Z;
    
% toc;
end

function y = normalizeLinf(x)
    y = zeros(size(x));

    [~, id] = max(x, [], 2);
    y(sub2ind(size(x), 1:size(x, 1), id')) = 1;
end

function y = normalizeL2(x)
    z = max(0, x);
    no = sqrt(sum(z.^2, 2));
    
    id = (no > eps) & (sum(x < 0, 2) ~= size(x, 2));
    idinf = ~id;
    
    y = zeros(size(x));
    y(id, :) = bsxfun(@rdivide, z(id, :), no(id));
    y(idinf, :) = normalizeLinf(x(idinf, :));
end

function [x, y, z, pi] = rproxF(X, Y, Z, f, Kif, Cij, phi, psi)
% Prox of the indicator function: X = Cij - \phi' pi \psi ; pi e = e ; e' pi =
% e' ; Y = pi ; Z = pi f

% disp('Projection');
% tic;
    n = size(f, 1);
    e = ones(n, 1);
%     normf = f'*f;
%     K = eye(n) + f*f';
%     Ki = eye(n) - f*f'/(1 + normf);
%     one = e - f*(sum(f)/(1 + normf)); % inv(I + f*f')*e %See Sherman�Morrison formula
    one = shermor(e, f, 'l', Kif); % inv(I + f*f')*e %See Sherman�Morrison formula

    matL = @(A) A - (e/n)*(e'*A); % (I - e*e'/n)*A
    matR = @(A) A - (A*e)*(one'/sum(one)); % A*(I - e*(Ki*e)'/(e'*Ki*e))
    KinvR = @(A) shermor(A, f, 'r', Kif); % A*Ki = A*inv(I + f*f') = A*(I - f*f'/(1 + f'*f))

    P = Y + Z*f';
    W = X - Cij + phi'*matL(matR(KinvR(P)))*psi + (phi'*e)*(e'*psi)/n;
    U = -phi'*matL(phi);
    V = matR(KinvR(psi'))*psi;

    alpha = dlyap(U, V, W);

    x = X - alpha;
    pi = matL(matR(KinvR(P - phi*alpha*psi'))) + e*(e'/n);
    y = pi;
    z = pi*f;

    %
    x = 2*x - X;
    y = 2*y - Y;
    z = 2*z - Z;
% toc;
end
