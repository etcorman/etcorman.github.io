function learnMapSCAPE(path, numRef, numTar, range, nbEigen, nbVF)

nameRef = nameSCAPE(numRef);
nameTar = nameSCAPE(numTar);
range = setdiff(range, [numRef, numTar]);
Max = length(range);


mesh0 = read_off([path, nameRef, '.off']);
mesh0 = MeshLB(mesh0, nbEigen, nbVF);

[fref, mask] = fctLearning(mesh0);
FRef = projectFunction(fref, mesh0.LB.basis, mesh0.A);
normalization = sqrt(sum(fref.^2));
FRef = FRef./repmat(normalization, [nbEigen, 1]);

nbFct = size(FRef, 2);

%%
map = zeros(nbEigen, nbEigen, Max); % Ref to i
F = zeros(nbEigen, nbFct, Max);
eigVal = zeros(nbEigen, Max);
for i = 1:Max
    
    disp(['Shape: ', nameSCAPE(range(i))]);
    mesh = read_off([path, nameSCAPE(range(i)), '.off']);
    
    mesh = MeshLB(mesh, nbEigen, 0);
    
    map(:, :, i) = mesh.LB.basis'*mesh.A*mesh0.LB.basis;

    [f, ~] = fctLearning(mesh);
    eigVal(:,i) = mesh.eigenvalues;
    
    % Projection and normalization
    normalization = sqrt(sum(f.^2));
    F(:,:,i) = projectFunction(f, mesh.LB.basis, mesh.A, normalization);
end

%% Initialization
W = zeros(nbEigen, nbEigen, Max);
for i = 1:Max
    W(:,:,i) = abs(repmat(abs(eigVal(:,i)) , [1, nbEigen]) - repmat(abs(mesh0.eigenvalues)' , [nbEigen, 1])) + 1;
end

alpha = 1e-3;
xinit = ones(nbFct, 1);

%% Set parameter from initial map
Soli = zeros(nbEigen, nbEigen, Max);
SvInit = zeros(nbEigen, Max);
for i = 1:Max
    Soli(:,:,i) = findFunMap(FRef, F(:,:,i), diag(xinit), W(:,:,i), alpha);
    SvInit(:,i) = svd(Soli(:,:,i) - map(:,:,i));
end

epsilon = flipud(mean(SvInit, 2));
epsilon = epsilon(sum(cumsum(epsilon)/sum(epsilon) <= 0.1));

%% Learning
mask = 1:nbFct;
funObj = @(x) oracleLearning(x, map, FRef, F, W, alpha, mask, 'l0', epsilon);
option.MaxIter = 100;
option.MaxFunEvals = option.MaxIter;
[x, fmin, exitflag] = minFunc(funObj, xinit, option);
D = diag(x);

%% Common basis
Sol = zeros(nbEigen, nbEigen, Max);
A = zeros(nbEigen*Max, nbEigen);
for i = 1:Max
    Sol(:,:,i) = findFunMap(FRef, F(:,:,i), D, W(:,:,i), alpha);
    A(nbEigen*(i-1) + 1:nbEigen*i,1:end) = Sol(:,:,i) - map(:,:,i);
end

[~, ~, V] = svd(A);
Ysub = fliplr(V);

%% Load Target
mesh1 = read_off([path, nameTar, '.off']);
mesh1 = MeshLB(mesh1, nbEigen, nbVF);

[f, ~] = fctLearning(mesh1);
normalization = sqrt(sum(f.^2));
G = projectFunction(f, mesh1.LB.basis, mesh1.A, normalization);

W0 = abs(repmat(abs(mesh1.eigenvalues) , [1, nbEigen]) - repmat(abs(mesh0.eigenvalues)' , [nbEigen, 1]))+1;
CRef = findFunMap(FRef, G, D, W0, alpha);

%% Save Stuff
save(['./Learning/Cache/weight_', nameRef, '_', nameTar, '.mat'] , 'mesh0', 'mesh1', 'CRef', 'Ysub');
