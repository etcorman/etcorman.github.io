Continuous Matching via Vector Field Flow,
Etienne Corman, Maks Ovsjanikov and Antonin Chambolle
Computer Graphics Forum (Proc. Symposium on Geometry Processing), 2015

- You might have to compile the mex file of the "minFunc" library. 
- Set the varibale "pathSCAPE" in "mainSCAPE.m" to the path of the SCAPE dataset (http://ai.stanford.edu/~drago/Projects/scape/scape.html). 
- Run "mainSCAPE.m"