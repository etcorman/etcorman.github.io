function [NewVert, corresp] = integrationVertex(mesh, idx, T, V)

Vert = mesh.vertices;
N = length(idx);

corresp = zeros(N, 1);
NewVert = zeros(3, N);
parfor i = 1:mesh.nv
    
    x = Vert(i,:)';
    
    [NewVert(:, i), corresp(i), ~] = integration(mesh, T, x, V, idx(i), 0);
    
    disp([num2str(idx(i)), ' correspond to ', num2str(corresp(i))]);
end

NewVert = NewVert';
