function [pt, vertex, path] = integration(mesh, T, x, V, num, type)

% INPUT
% mesh : struct
% T : final time
% x : starting point
% V : vector field
% numt : starting triangle

% OUTPUT
% pt : exact point
% vertex : nearest vertex of the graph
% triList : list of the visited triangles

Tri = mesh.triangles;
Vert = mesh.vertices;

v2e = mesh.adj.v2e;
v2e = v2e + v2e';

e2t = abs(mesh.adj.e2t(:,1:2));

ta = mesh.ta;

path(1, 1) = num;
path(1, 2) = type; % 2 = triangle, 0 = vertex

NextFace = true;

pt = x;
t = 0;
i = 1;
while (t < T)
    
    if ((path(i, 2) == 0) && NextFace)
        % At a vertex, we are looking for faces
        
        numvx = path(i, 1);
        [numts, ~] = find(Tri == numvx);
        
        dtTemp = 0;
        triTemp = 0;
        for j = 1:length(numts)
            vx1 = Tri(numts(j), 1);
            vx2 = Tri(numts(j), 2);
            vx3 = Tri(numts(j), 3);
            
            x1 = Vert(vx1,:)';
            x2 = Vert(vx2,:)';
            x3 = Vert(vx3,:)';
            
            v = V(numts(j),:)';
        
            [~, dt, edge] = intersectLineTri(x, v, x1, x2, x3);
            if ((dt > dtTemp) && (length(edge) == 1))
                dtTemp = dt;
                triTemp = numts(j);
            end
        end
        
        if (triTemp == 0) % We did not find a suitable triangle
            NextFace = false; 
        else % We are not on a vertex anymore
            vertex = false;
            i = i + 1;
            path(i, 1) = triTemp;
            path(i, 2) = 2;
        end
    elseif ((path(i, 2) == 0) && ~NextFace)
        % At a vertex we are looking for an edge
        
        numvx = path(i, 1);
        listEdge = v2e(:,numvx);
        listEdge(listEdge == 0) = [];
        listEdge = full(listEdge);
        
        vxTemp = 0;
        scalTemp = 0;
        for j = 1:length(listEdge)
            % We interpolate the vector field on the edge
            e = listEdge(j);
            if ((e2t(e,1) ~= 0) && (e2t(e,2) ~= 0))
                v = (V(e2t(e,1), :)*ta(e2t(e,1)) + V(e2t(e,2), :)*ta(e2t(e,2)))'/(ta(e2t(e,1)) + ta(e2t(e,2)));
            elseif (e2t(e,1) ~= 0)
                v = V(e2t(e,1), :)';
            elseif (e2t(e,2) ~= 0)
                v = V(e2t(e,2), :)';
            end
            
            [vxb, ~] = find(v2e(:,numvx) == e);
            xb = Vert(vxb,:)';
            
            scal = sum((xb - x).*v)/norm(xb - x);
            
            if (scal > scalTemp)
                pt = xb;
                vxTemp = vxb;
                v = scal*(xb - x)/norm(xb - x);
                dt = norm(x - xb)/abs(scal);
                scalTemp = scal;
            end
        end
        
        if (vxTemp == 0) % Fail : we did not find any good edge
            disp('STOP !! FAIL!!');
            t = T;
        else % We go along the edge and find a new vertex
            if (t + dt > T)
                pt = x + (T - t)*v;
                t = T;
            else
                x = pt;
                t = t + dt;
                i = i + 1;
                path(i, 1) = vxTemp;
                path(i, 2) = 0;
                NextFace = true;
            end
        end
    elseif (path(i, 2) == 2) 
        % We are at a Triangle
        
        numt = path(i, 1);
        vx1 = Tri(numt, 1);
        vx2 = Tri(numt, 2);
        vx3 = Tri(numt, 3);
        
        x1 = Vert(vx1,:)';
        x2 = Vert(vx2,:)';
        x3 = Vert(vx3,:)';
        v = V(numt,:)';
        
        [pt, dt, edge] = intersectLineTri(x, v, x1, x2, x3);
        
        if (isempty(edge)) % On reste sur l'ar�te
            % On trouve la bonne ar�te
            if (norm(cross(x - x1, x2 - x1)) < 1e-8*norm(x2 - x1))
                vxa = vx1; vxb = vx2;
                xa = x1; xb = x2;
            elseif (norm(cross(x - x2, x3 - x2)) < 1e-8*norm(x3 - x2))
                vxa = vx2; vxb = vx3;
                xa = x2; xb = x3;
            elseif (norm(cross(x - x3, x1 - x3)) < 1e-8*norm(x1 - x3))
                vxa = vx3; vxb = vx1;
                xa = x3; xb = x1;
            end
            
            e = full(v2e(vxa, vxb));
            
            if ((e2t(e,1) ~= 0) && (e2t(e,2) ~= 0))
                v = (V(e2t(e,1), :)*ta(e2t(e,1)) + V(e2t(e,2), :)*ta(e2t(e,2)))'/(ta(e2t(e,1)) + ta(e2t(e,2)));
            elseif (e2t(e,1) ~= 0)
                v = V(e2t(e,1), :)';
            elseif (e2t(e,2) ~= 0)
                v = V(e2t(e,2), :)';
            end
            
            scal = sum((xb - xa).*v)/norm(xb - xa);
            v = scal*(xb - xa)/norm(xb - xa);
            
            if (scal > 0)
                pt = xb;
                dt = norm(x - xb)/abs(scal);
                numvx = vxb;
            elseif (scal < 0)
                pt = xa;
                dt = norm(x - xa)/abs(scal);
                numvx = vxa;
            else
                disp('STOP !! Vecteur nul');
                t = T;
            end
            
            if (t + dt > T)
                pt = x + (T - t)*v;
                t = T;
            else
                x = pt;
                t = t + dt;
                i = i + 1;
                path(i, 1) = numvx;
                path(i, 2) = 0;
                NextFace = true;
            end
        elseif (length(edge) == 1) % Intersection avec une seul ar�te
            
            if (edge == 1)
                e = full(v2e(vx1, vx2));
            end
            if (edge == 2)
                e = full(v2e(vx2, vx3));
            end
            if (edge == 3)
                e = full(v2e(vx3, vx1));
            end
            if (e == 0)
                disp('WTF !! e ?');
                return
            end
            
            if (t + dt > T)
                pt = x + (T - t)*V(numt,:)';
                t = T;
            else
                x = pt;
                t = t + dt;
                i = i + 1;
                numt = (e2t(e,1) == numt).*e2t(e,2) + (e2t(e,2) == numt).*e2t(e,1);
                path(i, 1) = numt;
                path(i, 2) = 2;
                
                %         disp(['t = ', num2str(t), ' dt = ', num2str(dt), ' tri = ', num2str(numt)]);
            end
            if (numt == 0)
                disp('STOP !! Boundary');
                
                path(i, :) = [];
                t = T;
            end
        elseif (length(edge) == 2) % Intersection avec un sommet
            if (((edge(1) == 1) && (edge(2) == 2)) || ((edge(1) == 2) && (edge(2) == 1)))
                numvx = vx2;
            end
            if (((edge(1) == 2) && (edge(2) == 3)) || ((edge(1) == 3) && (edge(2) == 2)))
                numvx = vx3;
            end
            if (((edge(1) == 3) && (edge(2) == 1)) || ((edge(1) == 1) && (edge(2) == 3)))
                numvx = vx1;
            end
            
            if (t + dt > T)
                pt = x + (T - t)*V(numt,:)';
                t = T;
            else
                x = pt;
                t = t + dt;
                i = i + 1;
                path(i, 1) = numvx;
                path(i, 2) = 0;
                NextFace = true;
            end
        end
    end
end

% We find the nearest neightbor
if (path(end, 2) == 0) % Vertex case
    vertex = path(end, 1);
elseif (path(end, 2) == 2) % Face case
    numt = path(end, 1);
    vx1 = Tri(numt, 1);
    vx2 = Tri(numt, 2);
    vx3 = Tri(numt, 3);
    
    x1 = Vert(vx1,:)';
    x2 = Vert(vx2,:)';
    x3 = Vert(vx3,:)';
    
    [~, idx] = min([norm(pt - x1), norm(pt - x2), norm(pt - x3)]);
    vx = [vx1; vx2; vx3];
    vertex = vx(idx(1));
end