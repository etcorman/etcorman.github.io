function [itersect, pt, t, alpha] = intersectLineLine(x, v, x1, x2)

itersect = false;

A = [v, (x2 - x1)];
b = x2 - x;
a = A(1:2,:)\b(1:2);
t = a(1);
alpha = a(2);
pt = x + t*v;

if (abs(A(3,:)*a - b(3)) < 1e-8)
    itersect = true;
end