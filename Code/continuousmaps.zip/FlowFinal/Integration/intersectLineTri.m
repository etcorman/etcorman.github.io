function [pt, t, edge] = intersectLineTri(x, v, x1, x2, x3)

normv = norm(v);
v = v/normv;

X = [x1, x2, x3];
P = zeros(3, 3);
T = zeros(3, 1);
Al = zeros(3, 1);
Inter = zeros(3, 1);
for j = 1:3
    p = (j == 3)*1 + (j < 3)*(j+1);
    [Inter(j), P(1:3,j), T(j), Al(j)] = intersectLineLine(x, v, X(:,j), X(:,p));
    T(j) = T(j);
end
T = T/normv;

edge = find((T >= 1e-10).*(Al >= 0).*(Al <= 1).*(Inter == true));
if (length(edge) == 1) % Intersection avec une seule ar�te
    pt = P(:,edge);
    t = T(edge);
elseif (length(edge) == 2) % Intersection avec deux ar�tes == sommet
    pt = P(:,edge(1));
    t = T(edge(1));
else % Pas d'inersection, on reste sur l'ar�te
    edge = [];
    pt = x;
    t = 0;
end