clearvars; close all; clc;

paths_fvf

NF = 100; ND = 100;
k = 5; err = zeros(k,1); err2 = zeros(k,1);

for i = 1:k
    meshname = ['plane' num2str(2^(i-1)*10)];
    mesh = loadMeshLB(meshname,NF,ND);
    
    X = mesh.vertices; T = mesh.triangles; fvf = mesh.fvf;
    Xm = (X(T(:,1),:)+X(T(:,2),:)+X(T(:,3),:))/3;

    x = Xm(:,1); y = Xm(:,2);
    ze = zeros(mesh.nf,1);

    v1 = [x y ze];
    v2 = [-y x ze];
    cd_v1_v2 = cov_deriv_vf(mesh,v1,v2);
    
    % v1 & cd_v1_v2 are orthogonal
    f = dot(v1,cd_v1_v2,2).^2;
    g = normv(cd_v1_v2 - [-v1(:,2) v1(:,1) ze]);
    
    m1 = mean(f);
    m2 = mean(g);
    
    % any value above the mean is considered as a boundary value
    f(f>m1) = 0;
    err(i) = norm(f);
    
%     figure; show_func(mesh,double(g>m2));
%     sum(g>m2)/length(g)
    g(g>m2) = 0;
    err2(i) = norm(g);
end

% figure; %title('\left<v_1,\nabla_{v_1}(v_2)\right>');
% plot(err,'.','MarkerSize',30);
% figure; plot(err2,'.','MarkerSize',30); title('Error of computed vs. analytic'); 
