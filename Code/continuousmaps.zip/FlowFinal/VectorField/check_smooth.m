clearvars; close all; clc;

paths_fvf

NF = 20; ND = 20;

meshname = 'torus_exp_c';
mesh = loadMeshLB(meshname,NF,ND);

fvf = mesh.fvf;
fvf.vf = GS(fvf.vf);

% cd = compute_cdmat(mesh,fvf);
% save(['experiments\' meshname '_cd.mat'],'cd');
load(['experiments\' meshname '_cd.mat']);

[vf,ss] = compute_smooth(mesh,fvf,cd,12);
% vf = vf{1};
% figure; show_vf(mesh,vf,normv(vf));



% % addpath('geodesics_matlab\');
% % X = mesh.vertices; T = mesh.triangles;
% % shape.surface.X = X(:,1);
% % shape.surface.Y = X(:,2);
% % shape.surface.Z = X(:,3);
% % shape.surface.TRIV = T;
% % f = geodesics_pairs(shape,[(1:mesh.nv)' ones(mesh.nv,1)]);
% % vf = face_grads(mesh,f);
% % vf = normalize_vf(vf);
% % 
% % save(['experiments\' meshname '_gvf1.mat'],'vf');
% % load(['experiments\' meshname '_gvf1.mat']);
% X = mesh.vertices; T = mesh.triangles;
% Xm = [X(T(:,1),1) X(T(:,2),2) X(T(:,3),3)];
% % vf = cross(repmat([0 1 0],mesh.nf,1),mesh.N);
% vf = cross(Xm,mesh.N);
% 
% vf = normalize_vf(vf);
% 
% g1 = face_grads(mesh,func_f2v(mesh,vf(:,1)));
% g2 = face_grads(mesh,func_f2v(mesh,vf(:,2)));
% g3 = face_grads(mesh,func_f2v(mesh,vf(:,3)));
% 
% vv = [dot(vf,g1,2) dot(vf,g2,2) dot(vf,g3,2)];
% % cd_vv = cov_deriv_vf2(mesh,vv,vv);
% cd_vv = project_vf(mesh,vv);
% 
% figure; show_vf(mesh,cd_vv,normv(cd_vv));









% 
% v0 = reshape(mesh.fvf.vf(:,1),mesh.nf,3);
% v0 = rotate_vf(mesh,v0);
% v = v0;
% lambda = 1e-2;
% for i = 1:10
%     
%     cd_vv = cov_deriv_vf2(mesh,v,v);
%     sum(sum(cd_vv.^2,2))/mesh.nf
%     
% %     dv = cov_deriv_vf2(mesh,v,mesh.N);
%     dv = cov_deriv_vf2(mesh,v,v);
%     v = v - lambda*dv;
% end



























% % % v1 = mesh.N; v2 = mesh.N;
% % % v2x = func_f2v(mesh,v2(:,1));
% % % v2y = func_f2v(mesh,v2(:,2));
% % % v2z = func_f2v(mesh,v2(:,3));
% % % 
% % % gv2x = face_grads(mesh,v2x);
% % % gv2y = face_grads(mesh,v2y);
% % % gv2z = face_grads(mesh,v2z);
% % % 
% % % cdxy = [dot(v1,gv2x,2) dot(v1,gv2y,2) dot(v1,gv2z,2)];
% % % 
% % % 
% % % % vf = cov_deriv_vf2(mesh,mesh.N,mesh.N);
% % % figure; show_vf(mesh,cdxy,normv(cdxy));
% % 
% % % % cd = compute_cdmat(mesh,mesh.fvf);
% % % % save(['experiments\' meshname '_cd.mat'],'cd');
% % load(['experiments\' meshname '_cd.mat']);
% % % 
% % % % vf = compute_smooth(mesh,mesh.fvf,cd,3);
% % % 
% % A = zeros(ND*ND,ND);
% % for i = 1:ND
% %     
% %     A(:,i) = cd{i}(:);
% %         
% % end
% % 
% % [uu,ss,vv] = svd(A'*A);
% % % 
% % % % figure; show_vf(mesh,vf{2},normv(vf{2}));
% % % 

