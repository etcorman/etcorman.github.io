clearvars; close all; %clc;

paths_fvf

NF = 20; ND = 20;
meshname = ['teddy161'];
mesh = loadMeshLB(meshname,NF,ND);

fvf = mesh.fvf;
fvf.vf = GS(mesh.fvf.vf);

% cds = zeros(ND^2,ND);
% for i=1:ND
%     tic; cds(:,i) = reshape(vf2cd1(mesh, fvf, reshape(fvf.vf(:,i),mesh.nf,3)),ND^2,1); toc
% end
% 

%V = reshape(fvf.vf(:,2), mesh.nf, 3);
%V = project_vf(mesh, rand(mesh.nf,3));
V = mesh.N;

cd = vf2cd1(mesh, fvf, V);
[vv,dd] = eig(cd);

[ss,ii] = sort(diag(dd));
dd = dd(ii,ii); vv = vv(:,ii);
umin = reshape(fvf.vf*vv(:,1),mesh.nf,3);
figure;
show_vf(mesh,normalize_vf(umin)); title('umin');

umax = reshape(fvf.vf*vv(:,end),mesh.nf,3);
%figure;
show_vf(mesh,normalize_vf(umax)); title('umax');
% dd = real(dd);
% figure; plot(sort(diag(dd)),'.'); hold on
% plot(abs(sort(diag(dd))),'.r')
% title('sorted eigvals of \nabla X, ellipsoid, X first basis vec')
% legend('\lambda_i', 'abs(\lambda_i)')
% xlabel('i')
% 
% figure; show_vf(mesh, V, normv(V));

return

V = project_vf(mesh, rand(mesh.nf,3));
W = project_vf(mesh, rand(mesh.nf,3));
U = project_vf(mesh, rand(mesh.nf,3));

cdVU = cov_deriv_vf2(mesh,V,U);
cdVW = cov_deriv_vf2(mesh,V,W);
cdVUpW = cov_deriv_vf2(mesh,V,U+W);

% figure; show_vf(mesh,U,normv(U));
% title('$U$','interpreter','latex');
% figure; show_vf(mesh,V,normv(V));
% title('$V$','interpreter','latex');
% figure; show_vf(mesh,W,normv(W));
% title('$W$','interpreter','latex');
% figure; show_vf(mesh,cdVU+cdVW,normv(cdVU+cdVW)); 
% title('$\nabla_{V}(U) + \nabla_{V}(W)$','interpreter','latex');
% figure; show_vf(mesh,cdVUpW,normv(cdVUpW)); 
% title('$\nabla_{V}(U+W)$','interpreter','latex');
% 
res = norm(cdVUpW - (cdVU + cdVW),'fro');
fprintf('\n|cd_{V}(U+W)-(cd_{V}(U)+cd_{V}(W))| = %e\n\n',res);
    
