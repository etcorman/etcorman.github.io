function cd = compute_cdmat(mesh,fvf)

ND = fvf.ND;

cd = cell(ND,1);
for i = 1:ND
    cd{i} = zeros(ND);
    for j = 1:ND
        
        ei = reshape(fvf.vf(:,i),mesh.nf,3);
        ej = reshape(fvf.vf(:,j),mesh.nf,3);
        vf = cov_deriv_vf2(mesh,ei,ej);
%         [~,a] = no_proj(fvf.vf,vf(:));
        a = fvf.vf \ vf(:);
        cd{i}(:,j) = a;
        
    end
end
