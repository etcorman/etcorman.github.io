function v3 = lie_deriv(mesh,v1,v2)

cd_v1_v2 = cov_deriv_vf2(mesh,v1,v2);
cd_v2_v1 = cov_deriv_vf2(mesh,v2,v1);

v3 = cd_v1_v2 - cd_v2_v1;
% op = vf2op(mesh, v3);