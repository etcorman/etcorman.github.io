function vfr = rotate_vf(mesh, vf);
vfr = cross(mesh.N,vf);