function f = vorode1(t,y,mesh,M,L)
t
om = y;
warning off; s = -L\om; warning on
u = rotate_vf(mesh, face_grads(mesh, s));

dom = -f2v(mesh, M, dot(face_grads(mesh, om), u, 2));

f = dom;

function g = f2v(mesh, M, f)
F = repmat(f.*mesh.ta/3,1,3);
T = mesh.triangles;
I = [T(:,1); T(:,2); T(:,3)];
J = ones(size(I));
S = [F(:,1); F(:,2); F(:,3)];
g = sparse(I,J,S,mesh.nv,1);
g = spdiags(1./sum(M,2),0,mesh.nv,mesh.nv)*g;
g = full(g);
