clearvars; close all; clc;

paths_fvf

NF = 20; ND = 20;

meshname = 'sphere_s2';
mesh = loadMeshLB(meshname,NF,ND);

fvf = mesh.fvf;
fvf.vf = div_free(mesh,mesh.fvf);
fvf.vf = GS(fvf.vf);
mesh.fvf = fvf;

% w = rand(ND,1);
% w = w / norm(w);
w = zeros(ND,1); w(3) = 1;
dt = 10;

% pre-compute advection matrices
% C = compute_adv2(mesh,mesh.fvf);
% save(['experiments\' meshname '_adv2.mat'],'C');
load(['experiments\' meshname '_adv2.mat']);

X = mesh.vertices; T = mesh.triangles;
Xm = (X(T(:,1),:)+X(T(:,2),:)+X(T(:,3),:))/3;
fc = project_vf(mesh,cross(Xm,mesh.N));
f = 100*(fvf.vf \ fc(:));
% figure; show_vf(mesh,fc,normv(fc));

vf = reshape(fvf.vf*w,mesh.nf,3);
figure; show_vf(mesh,vf,normv(vf))

for i = 1:20
    
% start simulation
e1 = sum(w.*w);

wdt = zeros(ND,1);
for k = 1:ND
    wdt(k) = -w'*squeeze(C(k,:,:))*w;
end
w = w + wdt*dt;

e2 = sum(w.*w);
% w = w*sqrt(e1/e2);

% for k = 1:ND
    % viscosity
%     w(k) = w(k)*exp(-di   ag(fvf.evals(k))*dt);
    % external forces
    w(k) = w(k) + f(k);
% end

vf = reshape(fvf.vf*w,mesh.nf,3);
clf;
show_vf(mesh,vf,normv(vf))
pause(0.2);
end




