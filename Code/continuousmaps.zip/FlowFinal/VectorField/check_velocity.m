clearvars; close all; clc;

paths_fvf

NF = 20; ND = 20;

meshname = 'sphere_s2';
mesh = loadMeshLB(meshname,NF,ND);
fvf = mesh.fvf;

[W,A] = cotLaplacian(mesh);
L = spdiags(1./A,0,mesh.nv,mesh.nv);
L = L*W;

% fvf.vf = div_free(mesh,mesh.fvf);
fvf.vf = GS(fvf.vf);

% u = compute_akvf(mesh,fvf,3); u = u{3}; u = u ./ mean(normv(u));
% u = vf20div(mesh,L,u); % NOTE: u is probably not in span of the basis
% figure; show_vf(mesh,u,normv(u));

f = mesh.LB.basis(:,4)+mesh.LB.basis(:,6); 
fu = face_grads(mesh,f); fu = fu ./ mean(normv(fu));
u = rotate_vf(mesh,fu); e1 = sum(normv(u).^2);
% u = rand(mesh.nf,3); u = project_vf(mesh,u);
u = vf20div(mesh,L,u); % NOTE: u is probably not in span of the basis
u0 = u;
figure; show_vf(mesh,u,normv(u));

tspan = [0,1.5];
[T,Y] = ode45(@(t,y) velode1(t,y,mesh,L,zeros(mesh.nf,3)),tspan,u(:));

for i = 1:length(T)
    u2 = reshape(Y(i,:),mesh.nf,3);
%    e2 = sum(normv(u2).^2);
%    u2 = u2 * sqrt(e1/e2);
    clf;
    subplot(1,2,1);
    show_vf(mesh,u2,normv(u2));
    subplot(1,2,2);
    show_func(mesh,dcurl(mesh,u2));
    pause(0.01);
end

% dt = T(2:end) - T(1:end-1);
% Y2 = zeros(length(T),mesh.nf*3);
% for i = 2:k
%     
% du = cov_deriv_vf2(mesh,u,u);
% % du = fvf.vf'*du(:);
% % du = reshape(fvf.vf*du,mesh.nf,3);
% du = vf20div(mesh,L,du);
% 
% u = u - du*dt(i-1);
% Y2(i,:) = u(:);
% 
% % viscosity
% 
% % external forces
% % u = u + f;
% 
% % clf;
% % show_vf(mesh,u,normv(u));  view([1 0 0]);
% % pause(0.001);
% end


% % sanity check of a parabola
% tspan = [1,2];
% [T,Y] = ode45(@parabola,tspan,tspan(1));
% dt = T(2:end) - T(1:end-1);
% 
% Y2 = zeros(length(T),1); Y2(1) = tspan(1);
% k = length(T);
% for i = 2:k
%     dy = 2*T(i);
%     Y2(i) = Y2(i-1) + dy*dt(i-1);
% end
% 
% x = linspace(tspan(1),tspan(2),length(T)); Y3 = x.^2;
% figure; hold on; plot(Y,'r'); plot(Y3,'b'); %plot(Y3,'b');
