function show_func(mesh,f)
col = 'w';
if length(f) == mesh.nv
    col = 'interp';
elseif length(f) == mesh.nf
    col = 'flat';
end
if size(f,2) == 1
    cw = 'CData';
elseif size(f,2) == 3
    cw = 'FaceVertexCData';
end



patch('faces',mesh.triangles,'vertices',mesh.vertices,cw,f,'FaceColor',col,'EdgeColor','k'); colorbar
axis equal; cameratoolbar; cameratoolbar('SetCoordSys','none');