function VF = write_nrosy(name,mesh,vf,n)

vf = vf ./ repmat(normv(vf),1,3);

if nargin<3
    name = [mesh.name, '.rosy'];
end

nv = mesh.nv;
T = mesh.triangles;
A = mesh.ta;

fid = fopen(name,'w');
fprintf(fid,'%d %d\n', nv, n);

VF = zeros(nv,3);
for i = 1:nv
    
    id = [find(T(:,1) == i); ...
          find(T(:,2) == i); ...
          find(T(:,3) == i);];
    
    area = sum(A(id));
    
    for j = 1:length(id)
        
        w = A(id(j)) / area;
        VF(i,:) = VF(i,:) + w * vf(id(j),:);
        
    end
    VF(i,:) = VF(i,:) / length(id);
%     VF(i,:) = VF(i,:) / norm(VF(i,:));
    
    fprintf(fid,'%g %g %g\n', VF(i,1), VF(i,2), VF(i,3));
    
end

fclose(fid);

% figure; plot_vf_vquiver(mesh,VF);

