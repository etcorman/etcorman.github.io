clearvars; close all; %clc;

paths_fvf

NF = 100; ND = 100;

j = randi(ND,3,1);
err = zeros(5,1);
NV = zeros(5,1);
for i = 0:4
    meshname = ['sphere_s' num2str(i)];
    mesh = loadMeshLB(meshname,NF,ND);

    X = reshape(mesh.fvf.vf(:,j(1)),mesh.nf,3);
    Y = reshape(mesh.fvf.vf(:,j(2)),mesh.nf,3);
    Z = reshape(mesh.fvf.vf(:,j(3)),mesh.nf,3);
%     Z = rotate_vf(mesh,Y);

    DX = vf2op(mesh,X);
    fYZ = func_f2v(mesh,dot(Y,Z,2));
    cdXYZ = DX*fYZ;

    cdXY = cov_deriv_vf2(mesh,X,Y);
    cdXZ = cov_deriv_vf2(mesh,X,Z);

    fpg = func_f2v(mesh,dot(cdXY,Z,2)+dot(cdXZ,Y,2));

    err(i+1) = rmse(cdXYZ,fpg);
    NV(i+1) = mesh.nv;
end

figure; loglog(NV,err,'LineWidth',3);
xlabel('#vertices');
ylabel('error');
title('$RMSE(\nabla_{X}(<Y,Z>),<\nabla_{X}(Y),Z>+<Y,\nabla_{X}(Z)>)$','interpreter','latex');

% figure; show_func(mesh,cdXYZ);
% figure; show_func(mesh,fpg);
  
