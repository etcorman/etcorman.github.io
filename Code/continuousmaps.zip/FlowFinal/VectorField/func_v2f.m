function g = func_v2f(mesh,f)

T = mesh.triangles;

F = [f(T(:,1)) f(T(:,2)) f(T(:,3))];
VA = repmat(mesh.ta/3,1,3);
g = sum(F.*VA,2)./mesh.ta;