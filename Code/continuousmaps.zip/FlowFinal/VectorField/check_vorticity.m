clearvars; close all; clc;

paths_fvf

NF = 20; ND = 20;

meshname = 'sphere_s2';
mesh = loadMeshLB(meshname,NF,ND);
fvf = mesh.fvf;

[W,A] = cotLaplacian(mesh);
L = spdiags(1./A,0,mesh.nv,mesh.nv) * W;

f = mesh.LB.basis(:,4) + mesh.LB.basis(:,6); 
u = rotate_vf(mesh,face_grads(mesh,f)); 
om = dcurl(mesh, u);
u0 = u;
figure; show_vf(mesh,u,normv(u));

tspan = [0,3];
M = mass_matrix_barycentric(mesh);
[T,Y] = ode45(@(t,y) vorode1(t,y,mesh,M,L),tspan,om);

for i = 1:length(T)
    om = Y(i,:)';
    warning off;
    s = -L\om; 
    warning on
    u2 = rotate_vf(mesh, face_grads(mesh, s));
    
    clf;
    subplot(1,2,1);
    show_vf(mesh,u2,normv(u2));
    title(sprintf('u: \\int |u|^2=%g, t = %g', sum(normv(u2).^2), T(i)));

    subplot(1,2,2);
    show_func(mesh,dcurl_u(mesh,u2));
    title(sprintf('\\omega, \\int |omega|^2=%g, t = %g', sum(abs(om).^2), T(i)));
    
    pause(0.01);
end
