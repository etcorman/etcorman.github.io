function vf = div_free(mesh,fvf)

ND = fvf.ND;

[W,A] = cotLaplacian(mesh);
L = spdiags(1./A,0,mesh.nv,mesh.nv);
L = L*W;

vf = zeros(size(fvf.vf));
for i = 1:ND
    % extract div-free part of u
    
    u = reshape(fvf.vf(:,i),mesh.nf,3);
    div_u = ddiv(mesh,u);
    p = full(L\div_u);
    gp = face_grads(mesh,p);
    u = u-gp; 
    vf(:,i) = u(:);
end