function [vf,d,a,s] = compute_akvf(mesh, fvf, m)
N = mesh.LB.NF;

fvf_vf = fvf.vf; fvf_basis = compute_fbasis(mesh,fvf);

A = commute_LB(mesh,fvf_basis);

if nargin < 3
    m = 1;
end

% solve
[~,s,vv] = svd(A);
a = cell(m,1);
d = cell(m,1);
vf = cell(m,1);
for i = 1:m
    a{i} = vv(:,end-i+1);

    d{i} = reshape(fvf_basis*a{i},N,N);
    vf{i} = reshape(fvf_vf*a{i},mesh.nf,3);
end

if m == 1
    a = a{1};
    d = d{1};
    vf = vf{1};
end


