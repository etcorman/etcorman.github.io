function vf = project_vf(mesh, vf);
vf = vf - repmat(dot(vf,mesh.N,2),1,3).*mesh.N;