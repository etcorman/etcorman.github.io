function [mesh1, mesh2, V] = check_shape_diff;

addpath('../shapes/deform_sph');

Nf = 50; 

meshname1 = 'deform_sph_01';
meshname2 = 'deform_sph_16';


%% Read mesh
mesh1 = readMesh(meshname1);
mesh1 = cotLaplacian_local(mesh1);
[mesh1.vv,~] = eigs(mesh1.L, mesh1.A, Nf, 0);

mesh2 = readMesh(meshname2);
mesh2 = cotLaplacian_local(mesh2);
[mesh2.vv,~] = eigs(mesh2.L, mesh2.A, Nf*3, 0);


%% The real stuff
C = mesh2.vv\mesh1.vv;
V = C'*C;
size(V)

function mesh = readMesh(meshname);
[X T] = readOff([meshname '.off']);
N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
Ar = normv(N)/2;
N = N./repmat(normv(N),1,3);
mesh.vertices = X;
mesh.triangles = T;
mesh.nv = size(X,1);
mesh.nf = size(T,1);
mesh.N = N;
mesh.ta = Ar;

function mesh = cotLaplacian_local(mesh);
X = mesh.vertices;
T = mesh.triangles;
nv = mesh.nv;

% Find orig edge lengths and angles
L1 = normv(X(T(:,2),:)-X(T(:,3),:));
L2 = normv(X(T(:,1),:)-X(T(:,3),:));
L3 = normv(X(T(:,1),:)-X(T(:,2),:));
EL = [L1,L2,L3];
A1 = (L2.^2 + L3.^2 - L1.^2) ./ (2.*L2.*L3);
A2 = (L1.^2 + L3.^2 - L2.^2) ./ (2.*L1.*L3);
A3 = (L1.^2 + L2.^2 - L3.^2) ./ (2.*L1.*L2);
A = [A1,A2,A3];
A = acos(A);

% The Cot Laplacian 
I = [T(:,1);T(:,2);T(:,3)];
J = [T(:,2);T(:,3);T(:,1)];
S = 0.5*cot([A(:,3);A(:,1);A(:,2)]);
In = [I;J;I;J];
Jn = [J;I;I;J];
Sn = [-S;-S;S;S];
W = sparse(In,Jn,Sn,nv,nv);

mesh.L = W;
mesh.A = mass_matrix_barycentric(mesh);


% function op = vf2op_local(mesh,vf,bary)
% X = mesh.vertices;
% T = mesh.triangles;
% Nf = mesh.N;
% nv = mesh.nv;
% 
% v1 = X(T(:,1),:);
% v2 = X(T(:,2),:);
% v3 = X(T(:,3),:); 
% C1 = v3 - v2;
% C2 = v1 - v3;
% C3 = v2 - v1;
% Jc1 = cross(Nf, C1);
% Jc2 = cross(Nf, C2);
% Jc3 = cross(Nf, C3);
% 
% I = [T(:,1);T(:,2);T(:,3)];
% J = [T(:,2);T(:,3);T(:,1)];
% Sij = 1/6*[dot(Jc2,vf,2); dot(Jc3,vf,2); dot(Jc1,vf,2)];
% Sji = 1/6*[dot(Jc1,vf,2); dot(Jc2,vf,2); dot(Jc3,vf,2)];
% In = [I;J;I;J];
% Jn = [J;I;I;J];
% Sn = [Sij;Sji;-Sij;-Sji];
% W = sparse(In,Jn,Sn,nv,nv);
% 
% if bary == 1
%     M = mass_matrix_barycentric(mesh);
%     op = spdiags(1./sum(M,2),0,nv,nv)*W;
% else   
%     M = mass_matrix_voronoi(mesh);
%     op = inv(M)*W;
% end
% 
% 
% function g = func_v2f_local(mesh,f)
% T = mesh.triangles;
% F = [f(T(:,1)) f(T(:,2)) f(T(:,3))];
% g = sum(F/3,2);

% function g = func_f2v_local(mesh,f)
% % T = mesh.triangles;
% % J = [T(:,1); T(:,2); T(:,3)];
% % I = [1:mesh.nf, 1:mesh.nf, 1:mesh.nf]';
% % S = 1/3*ones(size(I));
% % A = sparse(I,J,S,mesh.nf,mesh.nv);
% % g = A\f; 
% T = mesh.triangles;
% F = repmat(f,1,3);
% F = F.*repmat(mesh.Ar/3,1,3);
% 
% I = [T(:,1); T(:,2); T(:,3)];
% J = ones(size(I));
% S = [F(:,1); F(:,2); F(:,3)];
% 
% g = sparse(I,J,S,mesh.nv,1);
% M = mass_matrix_barycentric(mesh);
% g = spdiags(1./sum(M,2),0,mesh.nv,mesh.nv)*g;
% % M = mass_matrix_voronoi(mesh);
% % g = spdiags(1./diag(M),0,mesh.nv,mesh.nv)*g;
% g = full(g);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


% function mesh = eigenstuff_vectors(mesh, ND);
% nf = mesh.nf;
% 
% [vv,dd] = eigs(mesh.dec.nabla1,ND,'sm');
% fvf.nh = size(vv,2);
% fvf.op = sparse(mesh.nv^2,fvf.nh);
% fvf.hvf = zeros(nf*3,fvf.nh);
% for i = 1:fvf.nh
%     if (dd(i,i) > 1e-3)
%         hvf = omega2U(mesh, vv(:,i) / dd(i,i));
%     else
%         hvf = omega2U(mesh, vv(:,i));
%     end
%     op = vf2op_local(mesh, hvf);
% 
%     fvf.op(:,i) = op(:);
%     fvf.hvf(:,i) = hvf(:);
% end
% mesh.fvf = fvf;
