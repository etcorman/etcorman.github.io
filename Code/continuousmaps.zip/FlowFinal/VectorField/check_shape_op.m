function [K,H,mesh] = check_shape_op(dir);

addpath('../shapes/kvfs');

meshname = 'moomoo';

%% Read mesh
mesh = readMesh(meshname);

%% The real stuff
Nv(:,1) = func_f2v_local(mesh, mesh.N(:,1));
Nv(:,2) = func_f2v_local(mesh, mesh.N(:,2));
Nv(:,3) = func_f2v_local(mesh, mesh.N(:,3));

W = project_vf(mesh, repmat(dir, mesh.nf, 1));
V = rotate_vf(mesh, W);

opW = vf2op_local(mesh, W);
Sw = zeros(mesh.nf,3);
Sw(:,1) = func_v2f_local(mesh,opW*Nv(:,1));
Sw(:,2) = func_v2f_local(mesh,opW*Nv(:,2));
Sw(:,3) = func_v2f_local(mesh,opW*Nv(:,3));
Sw = project_vf(mesh, Sw);

opV = vf2op_local(mesh, V);
Sv = zeros(mesh.nf,3);
Sv(:,1) = func_v2f_local(mesh,opV*Nv(:,1));
Sv(:,2) = func_v2f_local(mesh,opV*Nv(:,2));
Sv(:,3) = func_v2f_local(mesh,opV*Nv(:,3));
Sv = project_vf(mesh, Sv);

cVW = cross(V,W);
K = dot( cross(Sv, Sw) , cVW , 2) ./ dot(cVW, cVW, 2);
H = dot( cross(Sv, W) + cross(V, Sw) , cVW , 2) ./ dot(cVW, cVW, 2) / 2;

% Kalo SGP 06 paper 
xx = textread([mesh.name '.curv'],'','delimiter',' ');
K2 = xx(:,1).*xx(:,2);
figure; show_func(mesh, K2); dockfig; title('Gaussian Kalo');
H2 = (xx(:,1)+xx(:,2))/2;
figure; show_func(mesh, H2); dockfig; title('Mean Kalo');

figure; show_func(mesh, K); dockfig; title('Gaussian'); caxis([min(K2), max(K2)]);
figure; show_func(mesh, H); dockfig; title('Mean'); caxis([min(H2), max(H2)]);


function mesh = readMesh(meshname);
[X T] = readOff([meshname '.off']);
N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
Ar = normv(N)/2;
N = N./repmat(normv(N),1,3);
mesh.vertices = X;
mesh.triangles = T;
mesh.nv = size(X,1);
mesh.nf = size(T,1);
mesh.N = N;
mesh.Ar = Ar;
mesh.ta = mesh.Ar;
mesh.name = meshname;

function op = vf2op_local(mesh,vf,bary)
X = mesh.vertices;
T = mesh.triangles;
Nf = mesh.N;
nv = mesh.nv;

v1 = X(T(:,1),:);
v2 = X(T(:,2),:);
v3 = X(T(:,3),:); 
C1 = v3 - v2;
C2 = v1 - v3;
C3 = v2 - v1;
Jc1 = cross(Nf, C1);
Jc2 = cross(Nf, C2);
Jc3 = cross(Nf, C3);

I = [T(:,1);T(:,2);T(:,3)];
J = [T(:,2);T(:,3);T(:,1)];
Sij = 1/6*[dot(Jc2,vf,2); dot(Jc3,vf,2); dot(Jc1,vf,2)];
Sji = 1/6*[dot(Jc1,vf,2); dot(Jc2,vf,2); dot(Jc3,vf,2)];
In = [I;J;I;J];
Jn = [J;I;I;J];
Sn = [Sij;Sji;-Sij;-Sji];
W = sparse(In,Jn,Sn,nv,nv);

M = mass_matrix_barycentric(mesh);
op = spdiags(1./sum(M,2),0,nv,nv)*W;

function g = func_v2f_local(mesh,f)
T = mesh.triangles;
F = [f(T(:,1)) f(T(:,2)) f(T(:,3))];
g = sum(F/3,2);

function g = func_f2v_local(mesh,f)
% T = mesh.triangles;
% J = [T(:,1); T(:,2); T(:,3)];
% I = [1:mesh.nf, 1:mesh.nf, 1:mesh.nf]';
% S = 1/3*ones(size(I));
% A = sparse(I,J,S,mesh.nf,mesh.nv);
% g = A\f; 
T = mesh.triangles;
F = repmat(f,1,3);
F = F.*repmat(mesh.Ar/3,1,3);

I = [T(:,1); T(:,2); T(:,3)];
J = ones(size(I));
S = [F(:,1); F(:,2); F(:,3)];

g = sparse(I,J,S,mesh.nv,1);
M = mass_matrix_barycentric(mesh);
g = spdiags(1./sum(M,2),0,mesh.nv,mesh.nv)*g;
% M = mass_matrix_voronoi(mesh);
% g = spdiags(1./diag(M),0,mesh.nv,mesh.nv)*g;
g = full(g);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% function mesh = cotLaplacian_local(mesh);
% X = mesh.vertices;
% T = mesh.triangles;
% nv = mesh.nv;
% 
% % Find orig edge lengths and angles
% L1 = normv(X(T(:,2),:)-X(T(:,3),:));
% L2 = normv(X(T(:,1),:)-X(T(:,3),:));
% L3 = normv(X(T(:,1),:)-X(T(:,2),:));
% EL = [L1,L2,L3];
% A1 = (L2.^2 + L3.^2 - L1.^2) ./ (2.*L2.*L3);
% A2 = (L1.^2 + L3.^2 - L2.^2) ./ (2.*L1.*L3);
% A3 = (L1.^2 + L2.^2 - L3.^2) ./ (2.*L1.*L2);
% A = [A1,A2,A3];
% A = acos(A);
% 
% % The Cot Laplacian 
% I = [T(:,1);T(:,2);T(:,3)];
% J = [T(:,2);T(:,3);T(:,1)];
% S = 0.5*cot([A(:,3);A(:,1);A(:,2)]);
% In = [I;J;I;J];
% Jn = [J;I;I;J];
% Sn = [-S;-S;S;S];
% W = sparse(In,Jn,Sn,nv,nv);
% 
% % Compute the areas. Use mixed weights
% % Voronoi areas
% cA = 0.5*cot(A);
% vp1 = [2,3,1]; vp2 = [3,1,2];
% At = 1/4 * (EL(:,vp1).^2 .* cA(:,vp1) + EL(:,vp2).^2 .* cA(:,vp2));
% 
% % Triangle areas
% N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
% Ar = normv(N);
% 
% % Use barycentric area when cot is negative
% locs = find(cA(:,1) < 0);
% At(locs,1) = Ar(locs)/4; At(locs,2) = Ar(locs)/8; At(locs,3) = Ar(locs)/8;
% locs = find(cA(:,2) < 0);
% At(locs,1) = Ar(locs)/8; At(locs,2) = Ar(locs)/4; At(locs,3) = Ar(locs)/8;
% locs = find(cA(:,3) < 0);
% At(locs,1) = Ar(locs)/8; At(locs,2) = Ar(locs)/8; At(locs,3) = Ar(locs)/4;
% 
% % Vertex areas = sum triangles near by
% I = [T(:,1);T(:,2);T(:,3)];
% J = ones(size(I));
% S = [At(:,1);At(:,2);At(:,3)];
% A = sparse(I,J,S,nv,1);
% 
% mesh.origAreaWeights = 2*A;
% % Using **negative** cotLaplacian
% mesh.cotLaplace = -2*W;

% function mesh = eigenstuff_vectors(mesh, ND);
% nf = mesh.nf;
% 
% [vv,dd] = eigs(mesh.dec.nabla1,ND,'sm');
% fvf.nh = size(vv,2);
% fvf.op = sparse(mesh.nv^2,fvf.nh);
% fvf.hvf = zeros(nf*3,fvf.nh);
% for i = 1:fvf.nh
%     if (dd(i,i) > 1e-3)
%         hvf = omega2U(mesh, vv(:,i) / dd(i,i));
%     else
%         hvf = omega2U(mesh, vv(:,i));
%     end
%     op = vf2op_local(mesh, hvf);
% 
%     fvf.op(:,i) = op(:);
%     fvf.hvf(:,i) = hvf(:);
% end
% mesh.fvf = fvf;
