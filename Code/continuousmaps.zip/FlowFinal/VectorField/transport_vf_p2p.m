function [vf2,ee] = transport_vf_p2p(mesh1,mesh2,dest,vf1)

X1 = mesh1.vertices;
T1 = mesh1.triangles;
N1 = mesh1.N;
% A1 = mesh1.Ar;

X2 = mesh2.vertices(dest,:);
T2 = mesh2.triangles;
N2 = mesh2.N;
% A2 = mesh2.Ar;

vf2 = zeros(mesh1.nf,3);
for i=1:mesh1.nf
%     vfi = [vf1(i,:),0];    
%     Stet = [[X1(T1(i,1),:)',X1(T1(i,2),:)',X1(T1(i,3),:)',X1(T1(i,1),:)'+N1(i,:)'];1,1,1,1];
%     Ttet = [X2(T1(i,1),:)',X2(T1(i,2),:)',X2(T1(i,3),:)',X2(T2(i,1),:)'+N2(i,:)']; 
%     M = Ttet*inv(Stet);
%     ee(i) = norm(M*Stet - Ttet,'fro');    
%     M = inv([M;0,0,0,1])';
% %    ee(i) = cond(Stet);
%     vfo = (M*vfi')';
%     vf2(i,:) = vfo(1,1:3);
    x1 = [X1(T1(i,:),:);X1(T1(i,1),:)+N1(i,:)];
    ps1 = mean(x1);
    x1c = x1 - repmat(ps1,4,1);

    x2 = [X2(T2(i,:),:);X2(T2(i,1),:)+N2(i,:)];
    ps2 = mean(x2);
    x2c = x2 - repmat(ps2,4,1);

    M = x2c' * pinv(x1c');
    ee(i) = norm(M*x1c' - x2c','fro');   
    
%     scale = A1(i) / A2(i);
    t1 = vf1(i,:);
    t2 = M*t1';
    vf2(i,:) = t2';
end

