function C = compute_adv2(mesh,fvf)

ND = fvf.ND;
C = zeros(ND,ND,ND);

for i = 1:ND
    vi = reshape(fvf.vf(:,i),mesh.nf,3);
    for j = 1:ND
        vj = reshape(fvf.vf(:,j),mesh.nf,3);
        vf = cov_deriv_vf2(mesh,vi,vj);
        C(:,i,j) = fvf.vf \ vf(:);
    end
end