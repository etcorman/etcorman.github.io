clearvars; close all; clc;

paths_fvf

NF = 100; ND = 100;
meshname = 'plane80';
mesh = loadMeshLB(meshname,NF,ND);

X = mesh.vertices; x = X(:,1);
L = max(x)-min(x);

% analytic solution
t = linspace(0,1);
u0 = 1;                     % initial vector field
p1 = 1; p2 = 100;           % pressure at positions t=0,t=L
p = p1 - ((p1-p2)/L)*x;
u = ((p1-p2)/L)*t+u0;

% fvf solution
k = length(t);

figure;
for i = 1:k
    vf = repmat([u(i) 0 0],mesh.nf,1);
    clf; show_vf(mesh,vf,normv(vf));
    pause(0.2);
end
% v0 = [u0 0];
% 
% 
% 
% 
% 
% 
% 
% 
% fvf = mesh.fvf;
% a = rand(fvf.ND,1);
% u = reshape(fvf.vf*a,mesh.nf,3);
% 
% [W,A] = cotLaplacian(mesh);
% L = spdiags(1./A,0,mesh.nv,mesh.nv);
% L = L*W;
% 
% % extract div-free part of u
% div_u = ddiv(mesh,u);
% p = full(L\div_u);
% gp = face_grads(mesh,p);
% u = u-gp;
% 
% op = vf2op(mesh,u);
% [uu,ss,vv] = svd(full(op));
% f = vv(:,end-1);
% 
% % figure;
% k = 20; dt = .1; 
% div = zeros(k,1);
% for i = 1:k
%     f = f + dt*op*f;
%     div(i) = norm(ddiv(mesh,u));
%     cd_uu = cov_deriv_vf(mesh,u,u);
%     div_cd_uu = ddiv(mesh,cd_uu);
%     p = full(L\div_cd_uu);
%     gp = face_grads(mesh,p);
%     u = u + dt*(gp-cd_uu);
%     op = vf2op(mesh,u);
%     clf; show_vf(mesh,u,f); pause(0.2);
% end
% 
% figure; plot(div,'.','MarkerSize',20); title('divergence over time');