clearvars; close all; clc;

paths_fvf

NF = 20; ND = 20;

meshname = 'sphere_s2';
mesh = loadMeshLB(meshname,NF,ND);

[W,A] = cotLaplacian(mesh);
L = spdiags(1./A,0,mesh.nv,mesh.nv) * W;

b = 15;

% f
f = mesh.LB.basis(:,b); 
% u = *df
u = rotate_vf(mesh,face_grads(mesh,f)); 
if (norm(ddiv(mesh,u)) > 1e-8) error('??'); end 

% omega = *du = *d*df 
om = dcurl(mesh, u);

% g = -Delta f = - lambda f
g = -L*f;

% check omega = g, *d*df = -Delta f
if (norm(g - om) > 1e-8) error('??'); end

% domega\dt = -<nabla omega, u> = -lambda <nabla f, u> = -lambda <df, *df> 
dom = -dot(face_grads(mesh, om), u, 2);
domf = func_f2v(mesh, dom);

if norm(domf) > 1e-8 error('??'); end

'all is well, time to fly to NZ'