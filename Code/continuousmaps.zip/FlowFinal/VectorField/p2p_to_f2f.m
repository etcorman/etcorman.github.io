function fmap = p2p_to_f2f(basis1, basis2i, destinations)
if nargin < 3
    destinations = 1:size(basis1,1);
end
fmap = basis2i * basis1(destinations,:);