clearvars; close all; %clc;

paths_fvf

NF = 100; ND = 100;
meshname = ['sphere_s1'];
mesh = loadMeshLB(meshname,NF,ND);


V = project_vf(mesh, rand(mesh.nf,3));
W = project_vf(mesh, rand(mesh.nf,3));
U = project_vf(mesh, rand(mesh.nf,3));

cdVU = cov_deriv_vf2(mesh,V,U);
cdVW = cov_deriv_vf2(mesh,V,W);
cdVUpW = cov_deriv_vf2(mesh,V,U+W);

% figure; show_vf(mesh,U,normv(U));
% title('$U$','interpreter','latex');
% figure; show_vf(mesh,V,normv(V));
% title('$V$','interpreter','latex');
% figure; show_vf(mesh,W,normv(W));
% title('$W$','interpreter','latex');
% figure; show_vf(mesh,cdVU+cdVW,normv(cdVU+cdVW)); 
% title('$\nabla_{V}(U) + \nabla_{V}(W)$','interpreter','latex');
% figure; show_vf(mesh,cdVUpW,normv(cdVUpW)); 
% title('$\nabla_{V}(U+W)$','interpreter','latex');
% 
res = norm(cdVUpW - (cdVU + cdVW),'fro');
fprintf('\n|cd_{V}(U+W)-(cd_{V}(U)+cd_{V}(W))| = %e\n\n',res);
    
