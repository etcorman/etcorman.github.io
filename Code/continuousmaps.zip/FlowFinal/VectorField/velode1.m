function f = velode1(t,y,mesh,L,fu)

u = reshape(y,mesh.nf,3);

du = cov_deriv_vf2(mesh,u,u);
du = vf20div(mesh,L,du);
du = -du + fu;
f = du(:);