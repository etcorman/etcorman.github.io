function f = velode2(t,x)

f = 2*t;