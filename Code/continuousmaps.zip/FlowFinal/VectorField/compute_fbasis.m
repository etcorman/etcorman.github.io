function fbasis = compute_fbasis(mesh,fvf)

NF = mesh.LB.NF;
ND = fvf.ND;
basis = mesh.LB.basis;
basisi = mesh.LB.basisi;

fbasis = zeros(NF*NF,ND);
for i = 1:ND
    vf = reshape(fvf.vf(:,i),mesh.nf,3);
    [~,d] = cov_deriv(mesh,vf,basis,basisi);
    fbasis(:,i) = d(:);
end
