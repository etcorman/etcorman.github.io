function [A,b] = commute_LB(mesh,fvf_basis)

N = size(mesh.LB.basis,2);
L = mesh.LB.evals;

fvf_k = size(fvf_basis,2);

A = zeros(N^2,fvf_k);
b = zeros(N^2,1);
for i = 1:N
    for j = 1:N
        % L * sum_i a_i*D_i - sum_i a_i*D_i * L
        A((i-1)*N+j,:) = fvf_basis((i-1)*N+j,:) * (L(j) - L(i));
    end
end
