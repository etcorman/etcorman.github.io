function g = func_f2v(mesh,f)

F = repmat(f.*mesh.ta/3,1,3);

T = mesh.triangles;
I = [T(:,1); T(:,2); T(:,3)];
J = ones(size(I));
S = [F(:,1); F(:,2); F(:,3)];

g = sparse(I,J,S,mesh.nv,1);
M = mass_matrix_barycentric(mesh);
g = spdiags(1./sum(M,2),0,mesh.nv,mesh.nv)*g;
g = full(g);