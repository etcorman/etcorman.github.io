function divw = ddiv(mesh, w);

X = mesh.vertices;
T = mesh.triangles;

V1 = X(T(:,1),:);
V2 = X(T(:,2),:);
V3 = X(T(:,3),:);

C1 = V3 - V2;
C2 = V1 - V3;
C3 = V2 - V1;

N = cross(C1, C2); N = N./repmat(normv(N),1,3);

Jc1 = cross(N, C1);
Jc2 = cross(N, C2);
Jc3 = cross(N, C3);

I = [T(:,1); T(:,2); T(:,3)];
J = ones(length(I),1);
S = dot([Jc1; Jc2; Jc3], [w; w; w], 2);
nv = size(X,1);
divw = sparse(I,J,S, nv, 1)/2;

divw = divw ./ mesh.va;