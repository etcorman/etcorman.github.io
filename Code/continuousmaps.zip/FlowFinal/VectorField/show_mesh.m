function show_mesh(mesh)
patch('faces',mesh.triangles,'vertices',mesh.vertices,'FaceColor','w','EdgeColor','k'); 
axis equal; cameratoolbar; cameratoolbar('SetCoordSys','none');
hold on