function nvf = normalize_vf(vf)
nvf = vf./repmat(normv(vf),1,3);