function f = fun_cd2(x0)

global mesh
global a
meshname = mesh.name;
load(['experiments\' meshname '_M.mat']);

cd = zeros(mesh.nf,3);
for i = 1:mesh.fvf.ND
    A1 = x0(i) * M{i,1}*a;
    A2 = x0(i) * M{i,2}*a;
    A3 = x0(i) * M{i,3}*a;
    
    cd = cd + [A1 A2 A3];
end

f = sum(sum((cd-mesh.N).^2,2))/mesh.nf + sum((x0-a).^2)/mesh.fvf.ND;