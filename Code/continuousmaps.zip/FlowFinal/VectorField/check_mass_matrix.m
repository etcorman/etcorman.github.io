function check_mass_matrix;

addpath('../shapes/kvfs');

ND = 20; 

meshname = 'planers';
%meshname = 'plane_100x100';

% Use barycentric or voronoi area weights in operator
bary = 1;

%% Read mesh
mesh = readMesh(meshname);

%% The real stuff
X = mesh.vertices; T = mesh.triangles;
Xm = (X(T(:,1),:)+X(T(:,2),:)+X(T(:,3),:))/3;
x = Xm(:,1); y = Xm(:,2); zef = zeros(mesh.nf,1); zev = zeros(mesh.nv,1);

% 2 div-free VFs. v2 is on the vertices.
v1f = [zef x zef];
v2v = [X(:,2) zev zev];

op1 = vf2op_local(mesh, v1f, bary);
cdxy = zeros(mesh.nf,3);
cdxy(:,1) = func_v2f_local(mesh,op1*v2v(:,1));
cdxy(:,2) = func_v2f_local(mesh,op1*v2v(:,2));
cdxy(:,3) = func_v2f_local(mesh,op1*v2v(:,3));
cd_v1_v2 = cdxy - repmat(dot(cdxy,mesh.N,2),1,3).*mesh.N;
figure; show_func(mesh, normv(cd_v1_v2)); 

% 2 div-free VFs. v1 is on the vertices.
v1v = [zev X(:,1) zev];
v2f = [y zef zef];

op2 = vf2op_local(mesh, v2f, bary);
cdxy = zeros(mesh.nf,3);
cdxy(:,1) = func_v2f_local(mesh,op2*v1v(:,1));
cdxy(:,2) = func_v2f_local(mesh,op2*v1v(:,2));
cdxy(:,3) = func_v2f_local(mesh,op2*v1v(:,3));
cd_v2_v1 = cdxy - repmat(dot(cdxy,mesh.N,2),1,3).*mesh.N;
figure; show_func(mesh, normv(cd_v2_v1)); 

ld_v1_v2 = cd_v1_v2 - cd_v2_v1;
figure; show_func(mesh, normv(ld_v1_v2)); 

figure; show_vf(mesh,ld_v1_v2); 


function mesh = readMesh(meshname);
[X T] = readOff([meshname '.off']);
N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
Ar = normv(N)/2;
N = N./repmat(normv(N),1,3);
mesh.vertices = X;
mesh.triangles = T;
mesh.nv = size(X,1);
mesh.nf = size(T,1);
mesh.N = N;
mesh.Ar = Ar;

function op = vf2op_local(mesh,vf,bary)
X = mesh.vertices;
T = mesh.triangles;
Nf = mesh.N;
nv = mesh.nv;

v1 = X(T(:,1),:);
v2 = X(T(:,2),:);
v3 = X(T(:,3),:); 
C1 = v3 - v2;
C2 = v1 - v3;
C3 = v2 - v1;
Jc1 = cross(Nf, C1);
Jc2 = cross(Nf, C2);
Jc3 = cross(Nf, C3);

I = [T(:,1);T(:,2);T(:,3)];
J = [T(:,2);T(:,3);T(:,1)];
Sij = 1/6*[dot(Jc2,vf,2); dot(Jc3,vf,2); dot(Jc1,vf,2)];
Sji = 1/6*[dot(Jc1,vf,2); dot(Jc2,vf,2); dot(Jc3,vf,2)];
In = [I;J;I;J];
Jn = [J;I;I;J];
Sn = [Sij;Sji;-Sij;-Sji];
W = sparse(In,Jn,Sn,nv,nv);

if bary == 1
    M = mass_matrix_barycentric(mesh);
    op = spdiags(1./sum(M,2),0,nv,nv)*W;
else   
    M = mass_matrix_voronoi(mesh);
    op = inv(M)*W;
end


function g = func_v2f_local(mesh,f)
T = mesh.triangles;
F = [f(T(:,1)) f(T(:,2)) f(T(:,3))];
g = sum(F/3,2);

% function g = func_f2v_local(mesh,f)
% % T = mesh.triangles;
% % J = [T(:,1); T(:,2); T(:,3)];
% % I = [1:mesh.nf, 1:mesh.nf, 1:mesh.nf]';
% % S = 1/3*ones(size(I));
% % A = sparse(I,J,S,mesh.nf,mesh.nv);
% % g = A\f; 
% T = mesh.triangles;
% F = repmat(f,1,3);
% F = F.*repmat(mesh.Ar/3,1,3);
% 
% I = [T(:,1); T(:,2); T(:,3)];
% J = ones(size(I));
% S = [F(:,1); F(:,2); F(:,3)];
% 
% g = sparse(I,J,S,mesh.nv,1);
% M = mass_matrix_barycentric(mesh);
% g = spdiags(1./sum(M,2),0,mesh.nv,mesh.nv)*g;
% % M = mass_matrix_voronoi(mesh);
% % g = spdiags(1./diag(M),0,mesh.nv,mesh.nv)*g;
% g = full(g);


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% function mesh = cotLaplacian_local(mesh);
% X = mesh.vertices;
% T = mesh.triangles;
% nv = mesh.nv;
% 
% % Find orig edge lengths and angles
% L1 = normv(X(T(:,2),:)-X(T(:,3),:));
% L2 = normv(X(T(:,1),:)-X(T(:,3),:));
% L3 = normv(X(T(:,1),:)-X(T(:,2),:));
% EL = [L1,L2,L3];
% A1 = (L2.^2 + L3.^2 - L1.^2) ./ (2.*L2.*L3);
% A2 = (L1.^2 + L3.^2 - L2.^2) ./ (2.*L1.*L3);
% A3 = (L1.^2 + L2.^2 - L3.^2) ./ (2.*L1.*L2);
% A = [A1,A2,A3];
% A = acos(A);
% 
% % The Cot Laplacian 
% I = [T(:,1);T(:,2);T(:,3)];
% J = [T(:,2);T(:,3);T(:,1)];
% S = 0.5*cot([A(:,3);A(:,1);A(:,2)]);
% In = [I;J;I;J];
% Jn = [J;I;I;J];
% Sn = [-S;-S;S;S];
% W = sparse(In,Jn,Sn,nv,nv);
% 
% % Compute the areas. Use mixed weights
% % Voronoi areas
% cA = 0.5*cot(A);
% vp1 = [2,3,1]; vp2 = [3,1,2];
% At = 1/4 * (EL(:,vp1).^2 .* cA(:,vp1) + EL(:,vp2).^2 .* cA(:,vp2));
% 
% % Triangle areas
% N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
% Ar = normv(N);
% 
% % Use barycentric area when cot is negative
% locs = find(cA(:,1) < 0);
% At(locs,1) = Ar(locs)/4; At(locs,2) = Ar(locs)/8; At(locs,3) = Ar(locs)/8;
% locs = find(cA(:,2) < 0);
% At(locs,1) = Ar(locs)/8; At(locs,2) = Ar(locs)/4; At(locs,3) = Ar(locs)/8;
% locs = find(cA(:,3) < 0);
% At(locs,1) = Ar(locs)/8; At(locs,2) = Ar(locs)/8; At(locs,3) = Ar(locs)/4;
% 
% % Vertex areas = sum triangles near by
% I = [T(:,1);T(:,2);T(:,3)];
% J = ones(size(I));
% S = [At(:,1);At(:,2);At(:,3)];
% A = sparse(I,J,S,nv,1);
% 
% mesh.origAreaWeights = 2*A;
% % Using **negative** cotLaplacian
% mesh.cotLaplace = -2*W;

% function mesh = eigenstuff_vectors(mesh, ND);
% nf = mesh.nf;
% 
% [vv,dd] = eigs(mesh.dec.nabla1,ND,'sm');
% fvf.nh = size(vv,2);
% fvf.op = sparse(mesh.nv^2,fvf.nh);
% fvf.hvf = zeros(nf*3,fvf.nh);
% for i = 1:fvf.nh
%     if (dd(i,i) > 1e-3)
%         hvf = omega2U(mesh, vv(:,i) / dd(i,i));
%     else
%         hvf = omega2U(mesh, vv(:,i));
%     end
%     op = vf2op_local(mesh, hvf);
% 
%     fvf.op(:,i) = op(:);
%     fvf.hvf(:,i) = hvf(:);
% end
% mesh.fvf = fvf;
