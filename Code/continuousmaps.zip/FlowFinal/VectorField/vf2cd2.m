function cd = vf2cd2(mesh,fvf,vf)
% computes \nabla_{vf}()

cd = zeros(fvf.ND);
for i = 1:fvf.ND
    
    phi = reshape(fvf.vf(:,i),mesh.nf,3);
    cd_phi_vf = cov_deriv_vf2(mesh,vf,phi);
    [~,a] = no_proj(fvf.vf,cd_phi_vf(:));
    cd(:,i) = a;
    
end