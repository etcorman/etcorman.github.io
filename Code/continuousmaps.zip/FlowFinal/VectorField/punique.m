function vi = punique(v,d)
% this function gets a sorted vector and returns indices to the first
% unique elements of the vector allowing some error, i.e.
% norm(v(i)-(v+1)) < d will be regarded as equal.

vi = [];
pivot = v(1);

for i = 2:length(v)
    
    if norm(v(i)-pivot) < d, continue; end;
    
    vi = [vi; i-1];
    pivot = v(i);
    
end
