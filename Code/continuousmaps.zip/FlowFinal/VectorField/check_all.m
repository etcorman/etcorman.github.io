clc;

% 2. \nabla_{V}(U+W) = \nabla_{V}(U)+\nabla_{V}(W)
fprintf('Checking property 2:\n');
check_basic;

% 4. \nabla_{X}<Y,Z> = <\nabla_{X}(Y),Z> + <Y,\nabla_{X}(Z)>
fprintf('Checking property 4:\n');
check_fun_the;

% 14. \nabla_{X}(X)
fprintf('Checking property 14:\n');
check_geodesic2;

% 15. <\nabla_{Y}(X),Z> + <Y,\nabla_{Z}(X)> = 0
fprintf('Checking property 15:\n');
% check_kvf;

% 17. 
fprintf('Checking property 17:\n');
check_gt;