% Add cache directory
addpath('cache/');

% Add directory with model data
addpath('../shapes/');
addpath('../shapes/conformal');
addpath('../shapes/fvf');
addpath('../shapes/keenan');
addpath('../shapes/aim_shape');
addpath('../shapes/blender');
addpath('../shapes/scape');
addpath('../shapes/sumner');
addpath('../shapes/tosca');
addpath('../shapes/kvfs');
addpath('../shapes/tcods_vector_fields');
addpath('../shapes/drdaniel/samba');

% External libraries

% Add path for Maks' geodesics
% addpath('geodesics_matlab/');