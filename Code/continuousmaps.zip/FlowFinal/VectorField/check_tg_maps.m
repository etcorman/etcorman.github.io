clearvars; close all; clc;

paths_fvf

NF = 100; ND = 10;

% meshname1 = 'mesh000rep';
meshname1 = 'sphere_tg';
mesh1 = loadMeshLB(meshname1,NF,ND);

% meshname2 = 'mesh028rep';
meshname2 = 'ellipsoid_tg';
% meshname2 = 'sphere_tg';
% meshname2 = 'ssphere_tg';
mesh2 = loadMeshLB(meshname2,NF,ND);

% addpath('geodesics_matlab');
% X = mesh2.vertices; T = mesh2.triangles;
% shape.surface.X = X(:,1); shape.surface.Y = X(:,2); shape.surface.Z = X(:,3); shape.surface.TRIV = T;
% f = geodesics_pairs(shape,[(1:mesh2.nv)' 2078*ones(mesh2.nv,1)]);
% z2 = face_grads(mesh2,f);
% z2 = normalize_vf(z2);

% save('experiments/sphere_tg_d21.mat','z1');
% save('experiments/ellipsoid_tg_d21.mat','z2');
load('experiments/sphere_tg_d21.mat','z1');
z1t = transport_vf_p2p(mesh1,mesh2,1:mesh1.nv,z1); z1t = normalize_vf(z1t);
% load('experiments/ssphere_tg_d21.mat','z2');
load('experiments/ellipsoid_tg_d21.mat','z2'); z2 = normalize_vf(z2);

% sum(normv(z1t-z2))


% x1 = reshape(mesh1.fvf.vf(:,3),mesh1.nf,3);
% y1 = reshape(mesh1.fvf.vf(:,8),mesh1.nf,3);
% 
% x1t = transport_vf_p2p(mesh1,mesh2,1:mesh1.nv,x1);
% y1t = transport_vf_p2p(mesh1,mesh2,1:mesh1.nv,y1);
% 
% z1 = cov_deriv_vf(mesh1,x1,y1);
% z1t = transport_vf_p2p(mesh1,mesh2,1:mesh1.nv,z1);
% 
% z2 = cov_deriv_vf(mesh2,x1t,y1t);

% dest = 1:mesh2.nv;
% err = zeros(ND,ND);
% for i = 1:ND
%     x1 = reshape(mesh1.fvf.vf(:,i),mesh1.nf,3);
%     x2 = reshape(mesh2.fvf.vf(:,i),mesh2.nf,3);
%     
%     for j = 1:ND
%         y1 = reshape(mesh1.fvf.vf(:,j),mesh1.nf,3);
%         y2 = reshape(mesh2.fvf.vf(:,j),mesh2.nf,3);
%         
%         tic
%         z1 = cov_deriv_vf(mesh1,x1,y1);
%         z1t = transport_vf_p2p(mesh1,mesh2,dest,z1);
%         z2 = cov_deriv_vf(mesh2,x2,y2);
%         toc
%         err(i,j) = sum(normv(z1t-z2));
%     end
% end
% 
