function cd = vf2cd1(mesh,fvf,vf)
% computes \nabla_{}(vf)

cd = zeros(fvf.ND);
for i = 1:fvf.ND
    
    phi = reshape(fvf.vf(:,i),mesh.nf,3);
    cd_phi_vf = cov_deriv_vf2(mesh,phi,vf);
    [~,a] = no_proj(fvf.vf,cd_phi_vf(:));
    cd(:,i) = a;
    
end