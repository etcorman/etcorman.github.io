clearvars; close all; %clc;

paths_fvf

NF = 100; ND = 100;

meshname = 'dreidel2';
% meshname = 'cylinder';
mesh = loadMeshLB(meshname,NF,ND);

vf = cross(mesh.N,repmat([0 1 0],mesh.nf,1));
% vf = rotate_vf(mesh,vf);
% vf = cross(mesh.N,repmat([0 0 1],mesh.nf,1));
figure; show_vf(mesh,vf,normv(vf));

cd_vf = cov_deriv_vf2(mesh,vf,vf);
figure; show_vf(mesh,cd_vf,normv(cd_vf));