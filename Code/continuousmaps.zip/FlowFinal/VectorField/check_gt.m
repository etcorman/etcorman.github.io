clearvars; close all; %clc;

paths_fvf

NF = 100; ND = 100;

N = zeros(5,1);
err = zeros(5,1);
for i = 0:4
    meshname = ['sphere_s' num2str(i)];
    mesh = loadMeshLB(meshname,NF,ND);
    X = mesh.vertices;

    x = func_v2f(mesh,X(:,1)); 
    y = func_v2f(mesh,X(:,2)); 
    z = func_v2f(mesh,X(:,3));
    ze = zeros(mesh.nf,1);
    
    V = [-y,x,ze];
    W = [-z.*x,-z.*y,1 - z.*z];
%     acdWV = [z.*y - x.*x.*y.*z,-z.*x + x.*y.*y.*z,ze];
    acdWV = [y.*z, -x.*z, ze];
    ncdWV = cov_deriv_vf2(mesh,W,V);
    
    N(i+1) = mesh.nf;
    err(i+1) = rmse(acdWV(:),ncdWV(:));
%     figure; show_vf(mesh,V,normv(V));
%     title('$V$','interpreter','latex');
%     figure; show_vf(mesh,W,normv(W));
%     title('$W$','interpreter','latex');
%     figure; show_vf(mesh,acdWV,normv(acdWV)); 
%     title('Analytic $\nabla_{W}(V)$','interpreter','latex');
%     figure; show_vf(mesh,ncdWV,normv(ncdWV));
%     title('Computed $\nabla_{W}(V)$','interpreter','latex');
end

figure; loglog(N,err,'LineWidth',3.0);
xlabel('#faces'); ylabel('error');
title('RMSE(Analytic,Computed)');

% set(gca,'fontsize',30);
% xlabel('$#faces$','interpreter','latex');


