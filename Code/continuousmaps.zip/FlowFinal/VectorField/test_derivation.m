clearvars; close all; clc;

paths_fvf

NF = 100; ND = 100;

err = zeros(5,1);
for i = 0:4
    meshname = ['sphere_s' num2str(i)];
    mesh = loadMeshLB(meshname,NF,ND);
    
    % analytic KVF
    vf = cross(mesh.N,repmat([0,0,1],mesh.nf,1));
    op = vf2op(mesh,vf);
    
    a = rand(NF,1);
    f = mesh.LB.basis*a;
    
    fprintf('i=%d,f_err=%f. ',i,check_input(mesh,f));
    fprintf('i=%d,vf_err=%f\n',i,check_input(mesh,vf));
    
    g1 = op*f;
    g2 = func_f2v(mesh,dot(vf,face_grads(mesh,f),2));
        
    err(i+1) = norm(g1-g2) / norm(g2);
end

figure; plot(err,'.');
% figure; show_func(mesh,f);
% figure; show_func(mesh,g1);
% figure; show_func(mesh,g2);










