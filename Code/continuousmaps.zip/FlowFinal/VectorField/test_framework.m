clearvars; close all; clc;

% compare \nabla_{V}(f) to \dot(V,\nabla(f))
test_derivation

% compare \int(f_nv) to \int(f_nf)
% test_integration