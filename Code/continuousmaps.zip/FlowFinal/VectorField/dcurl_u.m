function curlw = dcurl_u(mesh, w);

X = mesh.vertices;
T = mesh.triangles;

V1 = X(T(:,1),:);
V2 = X(T(:,2),:);
V3 = X(T(:,3),:);

C1 = V3 - V2;
C2 = V1 - V3;
C3 = V2 - V1;

I = [T(:,1); T(:,2); T(:,3)];
J = ones(length(I),1);
S = dot([C1; C2; C3], [w; w; w], 2);
nv = size(X,1);
curlw = sparse(I,J,S, nv, 1)/2;

