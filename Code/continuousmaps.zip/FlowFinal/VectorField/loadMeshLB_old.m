function mesh = loadMeshLB_old(mesh,N,k,sphere)
% This method searches for meshname.mat if it exists and loads that. 
% Otherwise it tries to load meshname.off or meshname.obj, computes LB
% matrix/eigenstuff, and caches it for next time in meshname.mat.  It
% also can load the LB matrix and fill in eigenstuff if necessary.
% loadMeshLB returns two structures used for mesh and LB information.
%
% "Mesh" will be a structure storing all mesh data.

    if nargin < 3
        k = 0;
        sphere = false;
    end
    
    mesh = compute_LB(mesh);
    mesh = dec_it2(mesh);
    
    if sphere
        l = ceil(sqrt(N) - 1);%ceil((-3 + sqrt(1+8*N))/2);
        
        mesh.LB.basis = zeros(mesh.nv, N);
        mesh.LB.evals = zeros(N, 1);
            
        num = 0;
        for i = 0:l
            re = spherical_harmonic ( i, mesh );
            
            mesh.LB.basis(:,num+1:min(num+2*i+1,N)) = re(:,1:length(num+1:min(num+2*i+1,N)));
            mesh.LB.evals(num+1:min(num+2*i+1,N)) = i*(i + 1);
    
            num = num + 2*i + 1;
        end
        mesh.laplaceBasis = mesh.LB.basis;
        mesh.LB.evals = sparse(1:N, 1:N, mesh.LB.evals);
        mesh.eigenvalues = mesh.LB.evals;
        
        mesh.LB.basisi = pinv(mesh.LB.basis);
    else
        mesh = compute_functional_basis_weigthed_LB(mesh,N);%max(N+1,k+1));
    end
%     mesh = compute_functional_basis_unweigthed_LB(mesh,N);
    
    % Fix number of evals, depending on multiplicity
    if k > 0
%     N = check_multiplicity(mesh,N+1);
        mesh = compute_vf_basis_from_func_basis(mesh,N,k);
    end
    
%     [~, A] = cotLaplacian(mesh);
%     mesh.origAreaWeights = A;
    %     mesh.VA = vora(mesh);
        
    % Fix number of evals, depending on multiplicity
%     N = check_multiplicity(mesh,N+1);
%     
%     mesh.LB = truncate_basis(mesh.LB,N);
%     mesh.confLB = truncate_basis(mesh.confLB,N);
%     mesh.fvf = truncate_vbasis(mesh.fvf,N,k);
end


%%%%%
%% Load mesh from cache if it exists.
%% Recomputes vf basis if not a variable
%%%%
function mesh = load_mesh_from_cache(cache_file)
    load(cache_file);
    
    fprintf('Loading mesh from cache\n');
end

%%%%%
%% Parse mesh geometry from .mat file or .off
%%%%
function mesh = parse_mesh(meshname)
    % Load the mesh from .mat file
    if exist([meshname '.mat'],'file')==2
        % Loads a struct called "surface" with elements X, Y, Z, TRIV
        s = load([meshname '.mat']);
        mesh.triangles = s.surface.TRIV;
        mesh.vertices = [s.surface.X s.surface.Y s.surface.Z];
    % Load the mesh from .off file
    else
        [X T] = readOff([meshname '.off']);
        mesh.vertices = X;
        mesh.triangles = T;
    end
    mesh.nv = length(mesh.vertices);
    mesh.nf = length(mesh.triangles);
end

%%% 
% Compute weighted and unweighted cot LB
% Note that area weights are normalized to sum to 1
%%
function mesh = compute_LB(mesh)
    % triangle areas
    X = mesh.vertices; T = mesh.triangles;
    N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
    mesh.ta = normv(N)/2;    
    
    [W A] = cotLaplacian(mesh);
    mesh.origAreaWeights = 2*A;
    mesh.areaWeights = 2*A;
    % % Normalize mesh area to sum to 1
    mesh.areaWeights = mesh.areaWeights / sum(mesh.areaWeights);   
    % Using **negative** cotLaplacian
    mesh.cotLaplace = -2*W;
    
    %% For convenience...
    mesh.A = spdiags(mesh.areaWeights,0,mesh.nv,mesh.nv);
    mesh.Ai = spdiags(1./mesh.areaWeights,0,mesh.nv,mesh.nv);
    mesh.L = mesh.cotLaplace;
    mesh.Lw = mesh.Ai*mesh.L;
end

%%% 
% Eigenstuff of weighted LB
%%
function mesh = compute_functional_basis_weigthed_LB(mesh,N)
    [evecs, evals] = eigs(mesh.L, mesh.A, min(N,mesh.nv), -1e-3);
    evals = diag(evals);
%     evecs = repmat(sign(evecs(1,:)), size(evecs, 1), 1).*evecs;
    mesh.laplaceBasis = evecs;
    mesh.eigenvalues = evals;
    
    mesh.LB.basis = evecs;
%     mesh.LB.basisi = evecs'*mesh.A;
    mesh.LB.basisi = pinv(mesh.LB.basis);
    mesh.LB.evals = evals;    
end

%%% 
% Eigenstuff of unweighted LB
%%
function mesh = compute_functional_basis_unweigthed_LB(mesh,N);
    [evecs, evals] = eigs(mesh.L, min(max(N,100),mesh.nv), -1e-5);
    evals = diag(evals);
    
    mesh.confLB.basis = evecs;
    mesh.confLB.basisi = evecs';
    mesh.confLB.evals = evals;    
end

%%%
% Eigenstuff for VFs, as grads + rgrads + harmonic
function mesh = compute_vf_basis_from_func_basis(mesh,N,k)
    if k == 0
        return;
    end
    
    basis = mesh.LB.basis(:,1:N);
    basisi = mesh.LB.basisi(1:N,:);
    
    N = size(basis,2);
    nf = mesh.nf;

    % compute the harmonic VF and basis functions
    [vv,dd] = eigs(mesh.dec.nabla1,k,'sm');
    
    fvf.nh = size(vv,2);
    fvf.hvf = zeros(nf*3,fvf.nh);
    fvf.hbasis = zeros(N^2,fvf.nh);

    for i = 1:fvf.nh
%         hvf = omega2U(mesh, vv(:,i));
        if (dd(i,i) > 1e-3)
            hvf = omega2U(mesh, vv(:,i) / dd(i,i));
        else
            hvf = omega2U(mesh, vv(:,i));
        end
        
        [~,HD] = cov_deriv(mesh, hvf, basis, basisi);

        fvf.hvf(:,i) = hvf(:);
        fvf.hbasis(:,i) = HD(:);
    end
    fvf.hevals = dd;
    
    mesh.fvf = fvf;
end

%%%
% Change the number of basis functions, so we don't have extra stuff at the
% end
%%%
function N = check_multiplicity(mesh,N,err)
    if nargin < 3
        err = 1e-1;
    end

    v = punique(mesh.eigenvalues(1:N),err);
    [~,q] = min(abs(v - N));
    N = v(q);
end

%%%
% Truncate to N bases
%%
function b = truncate_basis(b,N)
    b.basis = b.basis(:,1:N);
    b.basisi = b.basisi(1:N,:);
    b.evals = b.evals(1:N);
end

function fvf = truncate_vbasis(fvf,N,k)
[ii,jj] = meshgrid(1:N,1:N);
siz = round(sqrt(size(fvf.hbasis(:,1),1)));
ind = sub2ind([siz,siz],jj,ii);
ind = ind(:);

fvf.hvf = fvf.hvf(:,1:k);
fvf.hbasis = fvf.hbasis(ind,1:k);
fvf.nh = k;

end

