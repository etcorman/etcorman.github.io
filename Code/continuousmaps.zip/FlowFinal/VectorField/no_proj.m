function [xp,c] = no_proj(A,x)

P = inv(A'*A)*A';
c = P*x;
xp = A*c;