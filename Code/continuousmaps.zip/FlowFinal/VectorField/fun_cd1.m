function f = fun_cd1(x0)

global mesh
global b
meshname = mesh.name;
load(['experiments\' meshname '_M.mat']);

cd = zeros(mesh.nf,3);
for i = 1:mesh.fvf.ND
    A1 = b(i) * M{i,1}*x0;
    A2 = b(i) * M{i,2}*x0;
    A3 = b(i) * M{i,3}*x0;
    
    cd = cd + [A1 A2 A3];
end

f = sum(sum((cd-mesh.N).^2,2))/mesh.nf;