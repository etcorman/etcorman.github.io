clearvars; close all; clc;

paths_fvf

NF = 100; ND = 100;

meshname = 'sphere_s2';
mesh = loadMeshLB(meshname,NF,ND);

i = 64; % i = randi(ND,1,1);
j = 10; % j = randi(ND,1,1);

v1 = reshape(mesh.fvf.vf(:,i),mesh.nf,3);
v2 = reshape(mesh.fvf.vf(:,j),mesh.nf,3);

op1 = vf2op(mesh,v1);
op2 = vf2op(mesh,v2);

[~,op3] = lie_deriv(mesh,v1,v2);
op4 = op1*op2-op2*op1;

k = 1000; x = mesh.vertices; me = .1*mean(normv(x(:,1)-x(:,2))); ze = zeros(3,1);
f1 = op3(k,:)';
f2 = op4(k,:)';

figure; show_func(mesh,f1); show_point(x(k,:),me,ze);
figure; show_func(mesh,f2); show_point(x(k,:),me,ze);