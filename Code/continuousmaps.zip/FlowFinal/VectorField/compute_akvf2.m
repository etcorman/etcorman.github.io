function vf = compute_akvf2(mesh, fvf, cd, m)

ND = fvf.ND;
A = zeros(ND*ND,ND);
for i = 1:ND
    for j = 1:ND
        
        t = (i-1)*ND+j;
        A(t,:) = cd{i}(j,:) + cd{j}(i,:);
        
    end
end

if nargin < 4
    m = 1;
end

% solve
[~,~,vv] = svd(A,0);
ta = cell(m,1);
vf = cell(m,1);
for i = 1:m
    ta{i} = vv(:,end+1-i);
    vf{i} = reshape(fvf.vf*ta{i},mesh.nf,3);
end

if m == 1
    vf = vf{1};
end


