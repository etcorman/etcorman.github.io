clearvars; close all; %clc;

paths_fvf

NF = 60; ND = 60;

meshname = 'sphere_s1';
global mesh;
global a;
global b;
mesh = loadMeshLB(meshname,NF,ND);
a = ones(ND,1);
b = ones(ND,1);

M = cell(ND,3);
for i = 1:ND
    ei = reshape(mesh.fvf.vf(:,i),mesh.nf,3);
    A1 = zeros(mesh.nf,ND);
    A2 = zeros(mesh.nf,ND);
    A3 = zeros(mesh.nf,ND);
    for j = 1:ND
        ej = reshape(mesh.fvf.vf(:,j),mesh.nf,3);
        gej1 = face_grads(mesh,ej(:,1));
        gej2 = face_grads(mesh,ej(:,2));
        gej3 = face_grads(mesh,ej(:,3));
        
        A1(:,j) = dot(ei,gej1,2);
        A2(:,j) = dot(ei,gej2,2);
        A3(:,j) = dot(ei,gej3,2);
    end
    M{i,1} = A1;
    M{i,2} = A2;
    M{i,3} = A3;
end
save(['experiments\' meshname '_M.mat'],'M');
load(['experiments\' meshname '_M.mat']);

% options = optimset('GradObj','on');
err = 1e-6;
for i = 1:ND
    x = fminunc(@fun_cd1,a);
    a = x;
    x = fminunc(@fun_cd2,b);
    if (norm(b-x) < err)
        break;
    end
    b = x;
end















% v1 = mesh.N; v2 = mesh.N;
% v2x = func_f2v(mesh,v2(:,1));
% v2y = func_f2v(mesh,v2(:,2));
% v2z = func_f2v(mesh,v2(:,3));
% 
% gv2x = face_grads(mesh,v2x);
% gv2y = face_grads(mesh,v2y);
% gv2z = face_grads(mesh,v2z);
% 
% cdxy = [dot(v1,gv2x,2) dot(v1,gv2y,2) dot(v1,gv2z,2)];
% 
% 
% % vf = cov_deriv_vf2(mesh,mesh.N,mesh.N);
% figure; show_vf(mesh,cdxy,normv(cdxy));
% 
% % % cd = compute_cdmat(mesh,mesh.fvf);
% % % save(['experiments\' meshname '_cd.mat'],'cd');
% % load(['experiments\' meshname '_cd.mat']);
% % 
% % % vf = compute_smooth(mesh,mesh.fvf,cd,3);
% % 
% % A = zeros(ND*ND,ND);
% % for i = 1:ND
% %     
% %     A(:,i) = cd{i}(:);
% %         
% % end
% % 
% % [~,ss,vv] = svd(A);
% % 
% % % figure; show_vf(mesh,vf{2},normv(vf{2}));
% % 
