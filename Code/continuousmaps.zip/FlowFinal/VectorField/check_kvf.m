clearvars; close all; %clc;

paths_fvf

NF = 20; ND = 20;

meshname = 'moomoo';
mesh = loadMeshLB(meshname,NF,ND);
basis = mesh.LB.basis; basisi = mesh.LB.basisi;
fvf = mesh.fvf;

fvf.vf = GS(fvf.vf);

% cd = compute_cdmat(mesh,fvf);
% save(['experiments\' meshname '_cd.mat'],'cd');
load(['experiments\' meshname '_cd.mat']);

vf = compute_akvf2(mesh,fvf,cd,1);
figure; show_vf(mesh,vf,normv(vf));

% % fbasis = zeros(fvf.ND*fvf.ND,ND);
% % for i = 1:fvf.ND
% %     vf = reshape(fvf.vf(:,i),mesh.nf,3);
% %     [~,d] = cov_deriv(mesh,vf,basis,basisi);
% %     fbasis(:,i) = d(:);
% % end
% % save(['experiments\' meshname '_fbasis.mat'],'fbasis');
% % load(['experiments\' meshname '_fbasis.mat']);
% % fvf.fbasis = fbasis;
% % 
% % [vf1,~] = compute_akvf(mesh,basis,fvf,1);
% 
% % % compute pairwise cov deriv
% cd = compute_cdmat(mesh,mesh.fvf);
% save(['experiments\' meshname '_cd.mat'],'cd');
% load(['experiments\' meshname '_cd.mat']);
% 
% vf = compute_akvf2(mesh,fvf,cd,3);
% figure; show_vf(mesh,vf{1},normv(vf{1}));
% figure; show_vf(mesh,vf{2},normv(vf{2}));
% figure; show_vf(mesh,vf{3},normv(vf{3}));
% 
% % 
% % % ax = rand(ND,1);
% % % ay = rand(ND,1); 
% % % err = zeros(5,1);
% % % NV = zeros(5,1);
% % % for j = 0:4
% % %     meshname = ['sphere_s' num2str(j)];
% % %     mesh = loadMeshLB(meshname,NF,ND);
% % % %     basis = mesh.LB.basis; basisi = mesh.LB.basisi;
% % %     fvf = mesh.fvf;
% % % 
% % % %     fbasis = zeros(fvf.ND*fvf.ND,ND);
% % % %     for i = 1:fvf.ND
% % % %         vf = reshape(fvf.vf(:,i),mesh.nf,3);
% % % %         [~,d] = cov_deriv(mesh,vf,basis,basisi);
% % % %         fbasis(:,i) = d(:);
% % % %     end
% % % %     fvf.fbasis = fbasis;
% % % 
% % % %     [vf,d] = compute_akvf(mesh,basis,fvf,1);
% % % %     save(['experiments\' meshname '_kvf1.mat'],'vf');
% % %     % vf = cross(mesh.N,repmat([0 1 0],mesh.nf,1));
% % %     load(['experiments\' meshname '_kvf1.mat']);
% % %     % figure; show_vf(mesh,vf,normv(vf));
% % % 
% % %     cd = vf2cd1(mesh,fvf,vf);
% % % 
% % % %     cd1 = fvf.vf * (cd * (fvf.vf \ vf(:)));
% % % %     cd2 = cov_deriv_vf(mesh,vf,vf);
% % %     
% % %     x = reshape(fvf.vf*ax,mesh.nf,3);
% % %     y = reshape(fvf.vf*ay,mesh.nf,3);
% % % 
% % %     cd_xv = cov_deriv_vf(mesh,x,vf);
% % %     cd_yv = cov_deriv_vf(mesh,y,vf);
% % % 
% % %     err(j+1) = sum((dot(cd_xv,y,2)+dot(cd_yv,x,2)).^2)/mesh.nv;
% % % %     err(j+1) = rmse(dot(cd_xv,y,2),-dot(cd_yv,x,2));
% % %     NV(j+1) = mesh.nv;
% % % end
% % % 
% % % figure; plot(NV,err);
% % % xlabel('#vertices');
% % % ylabel('error');
% % % 
% % % figure; show_func(mesh,dot(cd_xv,y,2));
% % % figure; show_func(mesh,dot(cd_yv,x,2));
