function [f,g]=func(mesh,v0)

cd_v0 = cov_deriv_vf(mesh,v0,v0);
f = sum(dot(cd_v0,cd_v0,2));
g = cd_v0;