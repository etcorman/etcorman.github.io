function [vf,op] = cov_deriv_vf2(mesh,v1,v2)

v2x = func_f2v(mesh,v2(:,1));
v2y = func_f2v(mesh,v2(:,2));
v2z = func_f2v(mesh,v2(:,3));

gv2x = face_grads(mesh,v2x);
gv2y = face_grads(mesh,v2y);
gv2z = face_grads(mesh,v2z);

cdxy = [dot(v1,gv2x,2) dot(v1,gv2y,2) dot(v1,gv2z,2)];

vf = cdxy - repmat(dot(cdxy,mesh.N,2),1,3).*mesh.N;
op = vf2op(mesh, vf);

