function [v,gp] = vf20div(mesh,L,u)

div_u = ddiv(mesh,u);
p = full(L\div_u);
gp = face_grads(mesh,p);
v = u-gp; 
    