function C = compute_adv(mesh,vf,cvf)

ND = size(vf,2);

C = zeros(ND,ND,ND);
for i = 1:ND
    vi = reshape(vf(:,i),mesh.nf,3);
    for j = 1:ND
        vj = reshape(cvf(:,j),mesh.nf,3);
        curl = dcurl_u(mesh,cross(vi,vj));
        f = repmat(func_v2f(mesh,curl),1,3);
        ld = reshape(f(:).*mesh.N(:),mesh.nf,3);
%         ld = lie_deriv(mesh,vi,vj);
        C(:,i,j) = cvf \ ld(:);
    end
end