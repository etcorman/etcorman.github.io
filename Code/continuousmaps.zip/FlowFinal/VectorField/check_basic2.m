clearvars; close all; clc;

paths_fvf

NF = 100; ND = 100;
meshname = 'sphere_s2';
mesh = loadMeshLB(meshname,NF,ND);

f = rand(mesh.nf,1);
g = rand(mesh.nf,1);

% rf = repmat(f,1,3);
% rg = repmat(g,1,3);
rf = ones(mesh.nf,3);
rg = ones(mesh.nf,3);

V = project_vf(mesh, rand(mesh.nf,3));
W = project_vf(mesh, rand(mesh.nf,3));
U = project_vf(mesh, rand(mesh.nf,3));

fV = rf.*V;
gW = rg.*W;

cdfVpgWU = cov_deriv_vf(mesh,fV+gW,U);

cdVU = cov_deriv_vf(mesh,V,U);
cdWU = cov_deriv_vf(mesh,W,U);

fcdVU = rf.*cdVU;
gcdWU = rg.*cdWU;

% figure; show_vf(mesh,U,normv(U));
% title('$U$','interpreter','latex');
% figure; show_vf(mesh,V,normv(V));
% title('$V$','interpreter','latex');
% figure; show_vf(mesh,W,normv(W));
% title('$W$','interpreter','latex');
% figure; show_vf(mesh,cdVU+cdVW,normv(cdVU+cdVW)); 
% title('$\nabla_{V}(U) + \nabla_{V}(W)$','interpreter','latex');
% figure; show_vf(mesh,cdVUpW,normv(cdVUpW)); 
% title('$\nabla_{V}(U+W)$','interpreter','latex');
% 
norm(cdfVpgWU - (fcdVU + gcdWU),'fro')

    
