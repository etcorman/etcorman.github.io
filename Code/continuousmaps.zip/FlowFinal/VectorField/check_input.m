function err = check_input(mesh,v)

if length(v) == size(v,2)
    v = v';
end

if size(v,2) == 1
    v2 = mesh.LB.basis*(mesh.LB.basis\v);
elseif size(v,2) == 3
    v2 = reshape(mesh.fvf.vf*(mesh.fvf.vf\v(:)),mesh.nf,3);
end

err = norm(v2(:)-v(:))/norm(v(:));