function curlw = dcurl(mesh, w);

curlw = dcurl_u(mesh, w);

curlw = curlw ./ mesh.va;