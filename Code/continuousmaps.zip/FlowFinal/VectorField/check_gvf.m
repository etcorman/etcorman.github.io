clearvars; close all; clc;

paths_fvf
addpath('geodesics_matlab/');

NF = 100; ND = 100;

ax = rand(ND,1);
ay = rand(ND,1); 
err = zeros(5,1); err2 = zeros(5,1);
NV = zeros(5,1);
for j = 0:2
    meshname = ['sphere_s' num2str(j)];
    mesh = loadMeshLB(meshname,NF,ND);
    fvf = mesh.fvf; X = mesh.vertices; T = mesh.triangles;
    
%     shape.surface.X = X(:,1);
%     shape.surface.Y = X(:,2);
%     shape.surface.Z = X(:,3);
%     shape.surface.TRIV = T;
%     f = geodesics_pairs(shape,[(1:mesh.nv)' ones(mesh.nv,1)]);
%     vf = face_grads(mesh,f);
%     vf = normalize_vf(vf);

%     save(['experiments\' meshname '_gvf1.mat'],'vf');
    load(['experiments\' meshname '_gvf1.mat']);
    % figure; show_vf(mesh,vf,normv(vf));

    cd = vf2cd1(mesh,fvf,vf);
  
    x = reshape(fvf.vf*ax,mesh.nf,3);
    y = reshape(fvf.vf*ay,mesh.nf,3);

    cd_xv = cov_deriv_vf(mesh,x,vf);
    cd_yv = cov_deriv_vf(mesh,y,vf);

    err(j+1) = sum((dot(cd_xv,y,2)-dot(cd_yv,x,2)).^2)/mesh.nv;
    err2(j+1) = rmse(dot(cd_xv,y,2),dot(cd_yv,x,2));
    NV(j+1) = mesh.nv;
end

figure; plot(NV,err);
xlabel('#vertices');
ylabel('error');

figure; show_func(mesh,dot(cd_xv,y,2));
figure; show_func(mesh,dot(cd_yv,x,2));
