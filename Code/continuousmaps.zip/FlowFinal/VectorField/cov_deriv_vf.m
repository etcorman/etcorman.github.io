function [vf,op] = cov_deriv_vf(mesh,v1,v2)

op1 = vf2op(mesh, v1);

v2x = func_f2v(mesh,v2(:,1));
v2y = func_f2v(mesh,v2(:,2));
v2z = func_f2v(mesh,v2(:,3));

cdxy = zeros(mesh.nf,3);
cdxy(:,1) = func_v2f(mesh,op1*v2x);
cdxy(:,2) = func_v2f(mesh,op1*v2y);
cdxy(:,3) = func_v2f(mesh,op1*v2z);

vf = cdxy - repmat(dot(cdxy,mesh.N,2),1,3).*mesh.N;
op = vf2op(mesh, vf);

