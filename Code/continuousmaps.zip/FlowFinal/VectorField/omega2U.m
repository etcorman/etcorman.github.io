function [U,Xm] = omega2U(mesh, omega, b);

X = mesh.vertices;
T = mesh.triangles;
N = mesh.N;
Ar = mesh.ta;
t2e = mesh.adj.t2e;

nf = length(T);

if nargin < 3
    b = [1,1,1];
end

w = omega(abs(t2e)).*sign(t2e);

P1 = X(T(:,3),:) - X(T(:,2),:);
P2 = X(T(:,1),:) - X(T(:,3),:);
P3 = X(T(:,2),:) - X(T(:,1),:);

P1r = cross(P1,N,2);
P2r = cross(P2,N,2);
P3r = cross(P3,N,2);

b = b/sum(b); bo=b; b = repmat(b, nf, 1);

U = repmat(w(:,2).*b(:,3) - w(:,3).*b(:,2),1,3).*P1r + ...
    repmat(w(:,3).*b(:,1) - w(:,1).*b(:,3),1,3).*P2r + ...
    repmat(w(:,1).*b(:,2) - w(:,2).*b(:,1),1,3).*P3r;
U = U./repmat(2*Ar,1,3);

Xm = X(T(:,1),:)*bo(1) + X(T(:,2),:)*bo(2) + X(T(:,3),:)*bo(3);