function show_point(p,r,c)

r = r/2;
phi = linspace(0,pi,30);
theta = linspace(0,2*pi,40);
[phi,theta] = meshgrid(phi,theta);

x = r*sin(phi).*cos(theta);
y = r*sin(phi).*sin(theta);
z = r*cos(phi);

if nargin<3
    c = randi(100,size(p,1),1);
end

hold on;
for i = 1:size(p,1)
    
    fc = c(i) * ones(size(x));
    
    mesh(x+p(i,1),y+p(i,2),z+p(i,3),'FaceColor','interp','EdgeColor','none',...
        'CData',fc);
end
hold off;
