clearvars; close all; clc;

paths_fvf

NF = 100; ND = 100;
meshname = 'sphere_s2';
[mesh,NF] = loadMeshLB(meshname, NF, ND);
fvf = mesh.fvf;

vf = reshape(fvf.hvf(:,2),mesh.nf,3);
figure; show_vf(mesh,vf,zeros(mesh.nv,1),1);