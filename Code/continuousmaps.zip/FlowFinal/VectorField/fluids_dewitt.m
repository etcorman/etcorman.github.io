clearvars; close all; clc;

paths_fvf

NF = 20; ND = 20;

meshname = 'sphere_s2';
mesh = loadMeshLB(meshname,NF,ND);

fvf.vf = div_free(mesh,mesh.fvf);
fvf = mesh.fvf;
fvf.vf = GS(fvf.vf);

% compute vorticity basis elements from velocity basis
cvf = zeros(3*mesh.nf,ND);
for k = 1:ND
    vf = reshape(fvf.vf(:,k),mesh.nf,3);
    fcvf = dcurl_u(mesh,vf);
    f = repmat(func_v2f(mesh,fcvf),1,3);
    cvf(:,k) = f(:).*mesh.N(:);
end
% TODO: check if it is still orthogonal

w = rand(ND,1);
w = w / norm(w);
dt = 1;

% pre-compute advection matrices
% C = compute_adv(mesh,fvf.vf,cvf);
% save(['experiments\' meshname '_adv.mat'],'C');
load(['experiments\' meshname '_adv.mat']);

vf = reshape(fvf.vf*w,mesh.nf,3);
figure; show_vf(mesh,vf,normv(vf))

for i = 1:200
    
% start simulation
e1 = sum(w.*w);

wdt = zeros(ND,1);
for k = 1:ND
    wdt(k) = w'*squeeze(C(k,:,:))*w;
end
w = w + wdt*dt;

e2 = sum(w.*w);
w = w*sqrt(e1/e2);

for k = 1:ND
    % viscosity
    w(k) = w(k)*exp(-diag(fvf.evals(k))*dt);
    % external forces
end

vf = reshape(fvf.vf*w,mesh.nf,3);
show_vf(mesh,vf,normv(vf))
pause(0.2);
end




