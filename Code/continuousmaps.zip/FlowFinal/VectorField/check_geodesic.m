clearvars; close all; clc;

paths_fvf

NF = 100; ND = 100;

meshname = 'ellipsoid_tg';
mesh = loadMeshLB(meshname,NF,ND);

load('experiments/ellipsoid_tg_d21.mat');
v0 = z2; clear z2;
v0 = normalize_vf(v0);
v0p = cross(mesh.N,v0); a = repmat(rand(mesh.nf,1),1,3);
v0 = v0+a.*v0p; 
v = v0; dt = 1; k = 100;

options = optimset('GradObj','on','MaxIter',10);
v = fminunc(@(x) func(mesh,x),v0,options);

% for i = 1:k
%     cd_v = cov_deriv_vf(mesh,v,v);
%     v = v - dt*cd_v;
%     v = normalize_vf(v);
% end
% 
% cd_v0 = cov_deriv_vf(mesh,v0,v0);
% cd_v = cov_deriv_vf(mesh,v,v);
% 
% sum(dot(cd_v0,cd_v0,2))
% sum(dot(cd_v,cd_v,2))
% sum(normv(cd_v0))
% sum(normv(cd_v))