function val = rmse(f1,f2)
mf2 = mean(f2);
val = sum((f1-f2).^2) / sum((f2-mf2).^2);