function mesh = loadMeshLB(meshname,NF,ND)
% This method searches for meshname.mat if it exists and loads that. 
% Otherwise it tries to load meshname.off or meshname.obj, computes LB
% matrix/eigenstuff, and caches it for next time in meshname.mat.  It
% also can load the LB matrix and fill in eigenstuff if necessary.
% loadMeshLB returns two structures used for mesh and LB information.
%
% "Mesh" will be a structure storing all mesh data.

    comp_LB = 0; comp_fvf = 0;
    
    cache_file = [meshname '_cache_v2.mat'];

    % Check if cache file exists and load it
    if exist(cache_file,'file')==2
        mesh = load_mesh(cache_file);
        
        if mesh.LB.NF < NF+1
            fprintf('Need more LB eigenfuncs, recomputing...\n');
            comp_LB = 1;
        end
        
        if mesh.fvf.ND < ND
            fprintf('Need more 1-forms eigenfuncs, recomputing...\n');
            comp_fvf = 1;
        end
    else
        mesh = parse_mesh(meshname);
        comp_LB = 1; comp_fvf = 1;
    end
    
    % Recompute LB if required
    if comp_LB
        tic; mesh = compute_LB(mesh,NF+1); toc;
        
        % Fix number of evals, depending on multiplicity
        NF = check_multiplicity(mesh,NF+1);
    end
    
    % Recompute FVF if required
    if comp_fvf
        mesh = dec_it2(mesh);
        tic; mesh = compute_fvf(mesh,ND); toc;
    end
        
    % Save mesh
    if comp_LB || comp_fvf
        save(['cache/' cache_file],'mesh');        
    end
    
    mesh = truncate_basis(mesh,NF);
    mesh = truncate_vf_basis(mesh,ND);
end


%%%%%
%% Load mesh from cache if it exists.
%% Recomputes vf basis if not a variable
%%%%
function mesh = load_mesh(cache_file)
    fprintf('Loading mesh from cache\n');
    load(cache_file);
end

%%%%%
%% Parse mesh geometry from .mat file or .off
%%%%
function mesh = parse_mesh(meshname)
    mesh.name = meshname;
    % Load the mesh from .mat file
    if exist([meshname '.mat'],'file')==2
        % Loads a struct called "surface" with elements X, Y, Z, TRIV
        s = load([meshname '.mat']);
        mesh.triangles = s.surface.TRIV;
        mesh.vertices = [s.surface.X s.surface.Y s.surface.Z];
    % Load the mesh from .off file
    else
        [X T] = readOff([meshname '.off']);
        mesh.vertices = X;
        mesh.triangles = T;
    end
    mesh.E = []; mesh.N = [];
    mesh.nv = length(mesh.vertices);
    mesh.nf = length(mesh.triangles);
    mesh.ne = 0;
    mesh.va = []; mesh.ta = [];
    mesh.LB = []; mesh.fvf = []; mesh.dec = []; mesh.adj = [];
end

%%% 
% Compute weighted and unweighted cot LB
% Note that area weights are normalized to sum to 1
%%
function mesh = compute_LB(mesh,NF)
    % triangle areas
    X = mesh.vertices; T = mesh.triangles;
    N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
    mesh.ta = normv(N)/2;

    [W A] = cotLaplacian(mesh);
    
    % Normalize mesh area to sum to 1
    mesh.va = full(A);
    % Using **positive** cotLaplacian
    LL = W;
    AA = spdiags(mesh.va,0,mesh.nv,mesh.nv);
    
    [evecs, evals] = eigs(LL, AA, min(max(NF,100), mesh.nv), 1e-3);
    [ss,ii] = sort(diag(evals));
    evals = evals(ii,ii); evecs = evecs(:,ii);
    mesh.LB.NF = NF;
    mesh.LB.basis = evecs;
    mesh.LB.basisi = pinv(evecs);   % TODO: verify
    mesh.LB.evals = diag(evals);    
end

%%%
% Change the number of basis functions, so we don't have extra stuff at the
% end
%%%
function N = check_multiplicity(mesh,N,err)
    if nargin < 3
        err = 1e-1;
    end

    v = punique(mesh.LB.evals(1:N),err);
    [~,q] = min(abs(v - N));
    N = v(q);
end

%%%
% Eigenstuff for VFs, use the 1-forms
function mesh = compute_fvf(mesh,ND)
    
    % compute the VF and basis functions
    [vv,dd] = eigs(mesh.dec.nabla1,ND,'sm');
    
    fvf.ND = ND;
    fvf.vf = zeros(mesh.nf*3,ND);
    for i = 1:ND
        if (dd(i,i) > 1e-3)
            vf = omega2U(mesh,vv(:,i)/dd(i,i));
        else
            vf = omega2U(mesh,vv(:,i));
        end
        fvf.vf(:,i) = vf(:);
    
    end
    fvf.evals = dd;
    
    mesh.fvf = fvf;
end

%%%
% Truncate to N bases
%%
function mesh = truncate_basis(mesh,NF)
    mesh.LB.NF = NF;
    mesh.LB.basis = mesh.LB.basis(:,1:NF);
    mesh.LB.basisi = mesh.LB.basisi(1:NF,:);
    mesh.LB.evals = mesh.LB.evals(1:NF);
end

function mesh = truncate_vf_basis(mesh,ND)
    mesh.fvf.ND = ND;
%     [ii,jj] = meshgrid(1:N,1:N);
%     siz = round(sqrt(size(fvf.hbasis(:,1),1)));
%     ind = sub2ind([siz,siz],jj,ii);
%     ind = ind(:);

    mesh.fvf.vf = mesh.fvf.vf(:,1:ND);
end

