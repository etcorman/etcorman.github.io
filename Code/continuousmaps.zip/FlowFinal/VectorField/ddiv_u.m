function divw = ddiv_u(mesh, w);

divw = ddiv(mesh,w);

divw = divw .* mesh.va;