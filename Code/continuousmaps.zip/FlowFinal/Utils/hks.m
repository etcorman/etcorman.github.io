function F = hks(L1, ts)
    N = size(L1.evecs,2);
    T1 = zeros(N, length(ts));
    D1 = L1.evecs(:,1:N)'*(L1.A*L1.evecs(:,1:N).^2);
    
    for i = 1:length(ts)
        T1(:, i) = exp(-abs(L1.evals(1:N))*ts(i));
    end
    F = D1*T1;
    F = L1.evecs*F;
end