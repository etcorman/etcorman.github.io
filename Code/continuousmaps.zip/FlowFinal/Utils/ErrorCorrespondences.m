function ErrorCorrespondences(mesh, pi, piEx, Sym)

if exist('Sym', 'var')
    symmetry = true;
else
    symmetry = false;
end

pairs = [pi, piEx];

surface.X = mesh.vertices(:,1);
surface.Y = mesh.vertices(:,2);
surface.Z = mesh.vertices(:,3);
surface.TRIV = mesh.triangles;

dist = dijkstra_pairs(surface, pairs);
if (symmetry == true)
    dist = min(dist, dijkstra_pairs(surface, [pi, Sym(piEx)]));
end

dsort = sort(dist);
cdf = zeros(length(dist), 1);
for i = 1:length(dist)
    cdf(i) = sum(dist <= dsort(i));
end
cdf = cdf/length(dist);

plot(sort(dist), cdf);
grid on;