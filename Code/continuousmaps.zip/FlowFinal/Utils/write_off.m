function write_off(filename, X, T)

fid = fopen(filename,'w');
if( fid==-1 )
    error('Cannot open the file.');
    return;
end

nv = size(X,1);
nf = size(T,1);

fprintf(fid, 'OFF\r\n');
fprintf(fid, '%d %d 0\r\n', nv, nf);

fprintf(fid, '%.9f %.9f %.9f\r\n', X');
fprintf(fid, '3 %d %d %d\r\n', (T-1)');

fclose(fid);