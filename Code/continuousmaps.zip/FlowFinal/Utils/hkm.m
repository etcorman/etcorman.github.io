function F = hkm(L1, numx, ts)
    N = size(L1.evecs,2);
    nv = size(L1.evecs,1);
    ntime = length(ts);
    
    T1 = zeros(N, ntime);
    
    for i = 1:ntime
        T1(:, i) = exp(-abs(L1.evals(1:N))*ts(i));
    end
    
    F = zeros(nv, ntime*length(numx));
    for i = 1:length(numx)
        F(:, ntime*(i-1) + 1:ntime*i) = (repmat(L1.evecs(numx(i),1:N), [nv, 1]).*L1.evecs(:,1:N))*T1;
    end
end