function y = meshSaliency(vertices, meanCurv, sigma)

nv = max(size(vertices));
nfct = length(sigma);
y = zeros(nv, nfct);

for i = 1:nv
    x = vertices(i,:);
    d = sum((vertices - repmat(x, [nv, 1])).^2, 2);
    
    for j = 1:nfct
        weight = (d < sigma(j)^2).*exp(-d/(2*sigma(j)^2));
        y(i, j) = sum(meanCurv.*weight)/sum(weight);
    end
end