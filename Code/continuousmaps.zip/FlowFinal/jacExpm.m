function [expD, J] = jacExpm(D, base)

nbase = size(base(:, :, 1), 1);
n = size(base, 3);
J = zeros(nbase, nbase, n);

for i = 1:n
    C = [D, zeros(size(D)); base(:, :, i), D];
    Exp = expm(C);
    J(:, :, i) = Exp(nbase + 1:end, 1:nbase);
end
expD = Exp(1:nbase, 1:nbase);