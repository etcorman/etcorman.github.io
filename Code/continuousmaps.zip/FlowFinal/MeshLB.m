function mesh = MeshLB(mesh,N,k)
% This method searches for meshname.mat if it exists and loads that. 
% Otherwise it tries to load meshname.off or meshname.obj, computes LB
% matrix/eigenstuff, and caches it for next time in meshname.mat.  It
% also can load the LB matrix and fill in eigenstuff if necessary.
% loadMeshLB returns two structures used for mesh and LB information.
%
% "Mesh" will be a structure storing all mesh data.

	if (~isfield(mesh,'LB'))
		mesh = compute_LB(mesh);
		mesh = compute_functional_basis_weigthed_LB(mesh,N);%max(N+1,k+1));
	end
    
    % Fix number of evals, depending on multiplicity
    if k > 0
        mesh = dec_it2(mesh);
        mesh = compute_vf_basis_from_func_basis(mesh,N,k);
    end
end

%%% 
% Compute weighted and unweighted cot LB
% Note that area weights are normalized to sum to 1
%%
function mesh = compute_LB(mesh)
    % triangle areas
    X = mesh.vertices; T = mesh.triangles;
    N = cross(X(T(:,1),:)-X(T(:,2),:), X(T(:,1),:) - X(T(:,3),:));
    mesh.ta = normv(N)/2;    
    
    [W, A] = cotLaplacian(mesh);
    mesh.origAreaWeights = 2*A;
    mesh.areaWeights = 2*A;
    % % Normalize mesh area to sum to 1
    mesh.areaWeights = mesh.areaWeights / sum(mesh.areaWeights);   
    % Using **negative** cotLaplacian
    mesh.cotLaplace = -2*W;
    
    %% For convenience...
    mesh.A = spdiags(mesh.areaWeights,0,mesh.nv,mesh.nv);
    mesh.Ai = spdiags(1./mesh.areaWeights,0,mesh.nv,mesh.nv);
    mesh.L = mesh.cotLaplace;
    mesh.Lw = mesh.Ai*mesh.L;
end

%%% 
% Eigenstuff of weighted LB
%%
function mesh = compute_functional_basis_weigthed_LB(mesh,N)
    [evecs, evals] = eigs(mesh.L, mesh.A, min(N,mesh.nv), -1e-5);
    evals = diag(evals);
    
    evecs = evecs*diag(sign(evecs(1,:)));
%     evecs = repmat(sign(evecs(1,:)), size(evecs, 1), 1).*evecs;
    mesh.laplaceBasis = evecs;
    mesh.eigenvalues = evals;
    
    mesh.LB.basis = evecs;
%     mesh.LB.basisi = evecs'*mesh.A;
    mesh.LB.basisi = pinv(mesh.LB.basis);
    mesh.LB.evals = evals;    
end

%%%
% Eigenstuff for VFs, as grads + rgrads + harmonic
function mesh = compute_vf_basis_from_func_basis(mesh,N,k)
    if k == 0
        return;
    end
    
    basis = mesh.LB.basis(:,1:N);
    basisi = mesh.LB.basisi(1:N,:);
    
    N = size(basis,2);
    nf = mesh.nf;

    % compute the harmonic VF and basis functions
    [vv,dd] = eigs(mesh.dec.nabla1,k,'sm');
    
    fvf.nh = size(vv,2);
    fvf.hvf = zeros(nf*3,fvf.nh);
    fvf.hbasis = zeros(N^2,fvf.nh);
    
    for i = 1:size(vv,2)
        if (dd(i,i) > 1e-3)
            hvf = omega2U(mesh, vv(:,i) / dd(i,i));
        else
            hvf = omega2U(mesh, vv(:,i));
        end
            
        [~,HD] = cov_deriv(mesh, hvf, basis, basisi);
            
        fvf.hvf(:,i) = hvf(:);
        fvf.hbasis(:,i) = HD(:);
    end
    fvf.hevals = dd;
    
    mesh.fvf = fvf;
end
